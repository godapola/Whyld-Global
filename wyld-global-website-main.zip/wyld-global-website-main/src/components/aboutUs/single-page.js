import React, { useState } from "react"
import { Document, Page } from "react-pdf/dist/esm/entry.webpack"
import { ChevronLeftIcon } from "@heroicons/react/outline"
import { ChevronRightIcon } from "@heroicons/react/outline"
// import SinglePage from "./single-page"

import samplePDF from "./sample.pdf"

const SinglePage = props => {
  const [numPages, setNumPages] = useState(null)
  const [pageNumber, setPageNumber] = useState(1) //setting 1 to show fisrt page

  function onDocumentLoadSuccess({ numPages }) {
    setNumPages(numPages)
    setPageNumber(1)
  }

  function changePage(offset) {
    setPageNumber(prevPageNumber => prevPageNumber + offset)
  }

  function previousPage() {
    changePage(-1)
  }

  function nextPage() {
    changePage(1)
  }

  const { pdf } = props

  return (
    <>
      <div className="flex justify-center lg:h-screen ">
        <div className=" lg:h-full group">
          <Document
            file={samplePDF}
            options={{ workerSrc: "/pdf.worker.js" }}
            onLoadSuccess={onDocumentLoadSuccess}
          >
            <Page pageNumber={pageNumber} />
          </Document>

          <div className="flex justify-center relative  ">
            <div className="flex gap-4 items-center  bg-white shadow-lg rounded-lg  absolute bottom-10 group-hover:opacity-100 opacity-0 duration-200 ">
              <button
                type="button"
                disabled={pageNumber <= 1}
                onClick={previousPage}
                className="hover:bg-slate-200  hover:rounded-lg duration-150 py-5 px-5 "
              >
                <ChevronLeftIcon className="w-4" />
              </button>
              <div className="">
                {pageNumber || (numPages ? 1 : "--")} of {numPages || "--"}
              </div>
              <button
                type="button"
                disabled={pageNumber >= numPages}
                onClick={nextPage}
                className="hover:bg-slate-200 hover:rounded-lg duration-150 py-5 px-5 "
              >
                <ChevronRightIcon className="w-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}
export default SinglePage
