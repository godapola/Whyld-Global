import * as React from "react"
import { useState } from "react"
import { Range, getTrackBackground, useThumbOverlap } from "react-range"

const STEP = 1
const MIN = 20
const MAX = 100
const COLORS = ["#ccc", "#000", "#ccc"]
const COLORS2 = ["#000", "#ccc"]
const THUMB_SIZE = 42

const ThumbLabel = ({ rangeRef, values, index }) => {
  const [labelValue, style] = useThumbOverlap(rangeRef, values, index)
  return (
    <div
      data-label={index}
      className="block absolute -top-14 font-semibold p-4 text-2xl "
    >
      {labelValue + "K"}
    </div>
  )
}

class Sophistication extends React.Component {
  state = {
    values: [50],
  }
  rangeRef = React.createRef()
  trackRef = React.createRef()
  onChange = values => {
    this.props.getRangeValuesSophiscation(values)
    this.setState({
      values,
    })
  }

  render() {
    return (
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          flexWrap: "wrap",
        }}
      >
        <Range
          allowOverlap
          values={this.state.values}
          ref={this.rangeRef}
          step={STEP}
          min={MIN}
          max={MAX}
          onChange={this.onChange}
          renderTrack={({ props, children }) => (
            <div
              onMouseDown={props.onMouseDown}
              onTouchStart={props.onTouchStart}
              style={{
                ...props.style,
                height: "36px",
                display: "flex",
                width: "100%",
              }}
            >
              <div
                ref={props.ref}
                style={{
                  height: "12px",
                  width: "100%",
                  borderRadius: "4px",
                  background: getTrackBackground({
                    values: this.state.values,
                    colors: COLORS2,
                    min: MIN,
                    max: MAX,
                  }),
                  alignSelf: "center",
                }}
              >
                {children}
              </div>
            </div>
          )}
          renderThumb={({ props, index, isDragged }) => {
            return (
              <div
                {...props}
                className="rounded-full h-10 w-10 bg-black shadow-lg relative "
              ></div>
            )
          }}
        />
      </div>
    )
  }
}

export default Sophistication
