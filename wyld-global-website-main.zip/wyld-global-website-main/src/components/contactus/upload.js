import React, { useState, useCallback } from "react"
import { useDropzone } from "react-dropzone"
import { CloudUploadIcon } from "@heroicons/react/outline"
import { XCircleIcon } from "@heroicons/react/solid"

function Uploader(props) {
  const [user, setUser] = useState("Jesse Hall")
  const [myFiles, setMyFiles] = useState([])

  const onDrop = useCallback(
    acceptedFiles => {
      setMyFiles(
        [...myFiles, ...acceptedFiles].map(file =>
          Object.assign(file, {
            preview: URL.createObjectURL(file),
          })
        )
      )
    },
    [myFiles]
  )

  const afterDropFiles = () => {
    console.log(props.getData(myFiles))
  }

  afterDropFiles()

  const { getRootProps, getInputProps } = useDropzone({
    onDrop,
  })

  const removeFile = file => {
    const newFiles = [...myFiles]
    newFiles.splice(file, 1)
    setMyFiles(newFiles)
  }

  const files = myFiles.map(file => (
    <div key={file.name}>
      <div>
        <img
          src={file.preview}
          // Revoke data uri after image is loaded
          onLoad={() => {
            URL.revokeObjectURL(file.preview)
          }}
        />
      </div>
    </div>
  ))

  return (
    <section className="container">
      <div
        className="py-20 w-full border-2 border-dashed rounded-3xl"
        {...getRootProps()}
      >
        <input {...getInputProps()} />
        <div className="flex justify-center">
          <div>
            <div className="flex justify-center py-4">
              <CloudUploadIcon className="w-24 text-gray-400 text-center" />
            </div>

            <div className="text-center text-xl text-gray-400 font-semibold">
              Drag and Drop Files here
            </div>
            <div className="flex gap-3 justify-center">
              <div className=" text-gray-400">or</div>
              <div className="text-red-600 font-semibold  ">Browse</div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid gap-6 grid-cols-5 mt-8">
        {myFiles.map((item, index) => {
          return (
            <div key={index} className="px-2  pt-2 border rounded-xl  relative">
              <XCircleIcon
                className="w-6 text-red-600 absolute -top-4 -right-5 cursor-pointer hover:scale-125 duration-300"
                onClick={() => removeFile(index)}
              />
              <div className="">
                <img
                  src={URL.createObjectURL(item)}
                  alt={item.name}
                  className="rounded-xl"
                />
              </div>

              <div className="py-4 text-sm ">{item.name}</div>
            </div>
          )
        })}
      </div>
    </section>
  )
}

export default Uploader
