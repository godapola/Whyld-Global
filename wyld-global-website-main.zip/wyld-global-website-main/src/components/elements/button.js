import { Link } from "gatsby"
import React from "react"
import { ArrowNarrowRightIcon } from "@heroicons/react/solid"
import { useState } from "react"

const Button = props => {
  const [active, setActive] = useState()
  return (
    <Link to={props.link}>
      <button
        type={props.type}
        className={
          props.filled
            ? "py-1 px-6 border border-black rounded-full cursor-pointer bg-black text-white group"
            : props.filledWhite
            ? "py-1 px-6 border border-white rounded-full cursor-pointer bg-white text-black group"
            : "py-1 px-6 border border-black rounded-full cursor-pointer group"
        }
      >
        <div className="flex items-center">
          <div className="">{props.title}</div>
          <div className="">
            <ArrowNarrowRightIcon
              className={
                props.filled
                  ? "w-5 -ml-8 group-hover:ml-2 duration-200 text-transparent group-hover:text-white"
                  : "w-5 -ml-8 group-hover:ml-2 duration-200 text-transparent group-hover:text-black"
              }
            />
          </div>
        </div>
      </button>
    </Link>
  )
}

export default Button
