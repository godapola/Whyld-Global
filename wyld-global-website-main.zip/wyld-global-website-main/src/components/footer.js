import * as React from "react"
import PropTypes from "prop-types"
import { Link } from "gatsby"
// import { Clock } from "global-clock"
import Clock from "react-live-clock"
import { StaticImage } from "gatsby-plugin-image"

const Footer = () => {
  //   const dubai = Clock.getFullTime()
  //   console.log(dubai)
  const locations = [
    {
      city: "Dubai",
      time: "Asia/Dubai",
    },
    {
      city: "Los Angeles",
      time: "America/Los_Angeles",
    },
    {
      city: "New York",
      time: "America/New_York",
    },
    {
      city: "London",
      time: "Europe/London",
    },
    {
      city: "Colombo",
      time: "Asia/Colombo",
    },
    {
      city: "Mumbai",
      time: "Asia/Colombo",
    },
  ]
  return (
    <div className="">
      <div className="py-4 bg-light-gray ">
        <div className="container mx-auto px-10">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:gap-0 gap-8 lg:grid-cols-6">
            {locations.map((item, index) => {
              return (
                <div className="text-center">
                  <div key={index}>
                    <div className="font-semibold mb-1 ">{item.city}</div>
                    <div className="">
                      <Clock
                        // format={"h:mm:ss"}
                        ticking={true}
                        timezone={item.time}
                        time={"full"}
                      />
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </div>
      <div className="container mx-auto px-10 py-20">
        <div className="flex lg:flex-row flex-col items-center lg:gap-0 gap-10 lg:justify-between">
          <div>
            <StaticImage
              src="../images/brand/logo.png"
              className="w-40 xl:w-52"
              alt="wyld global"
            />
          </div>
          <div>
            <div className="flex md:flex-row flex-col gap-10 text-center md:text-left md:gap-32">
              <div>
                <div className="font-semibold">Start a project</div>
                <div className="mt-2">business@wyld.global</div>
              </div>
              <div>
                <div className="font-semibold">Speak to us</div>
                <div className="mt-2">hello@wyld.global</div>
                <div className="mt-2">
                  <a href="tel:+91 7123 456 78">+91 7123 456 78</a>
                </div>
              </div>
              <div>
                <div className="font-semibold">Headquaters</div>
                <div className="mt-2">51,</div>
                <div className="mt-2">5th Lan,</div>
                <div className="mt-2">Colombo 03</div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="bg-dark-gray/20 py-2">
        <div className="container mx-auto px-10 py-1 md:text-left text-center">
          <div className="flex xl:flex-row flex-col xl:gap-0 gap-5 justify-between ">
            <div className="md:flex-row flex-col flex gap-5 text-black/40">
              <div className="text-xs">
                Copyright © 2022 WYLD Global, A Trademark of WYLD Marketing
                Services.
              </div>
              <div className="flex md:justify-start justify-center gap-5">
                <div className="text-xs">
                  Developed by{" "}
                  <a
                    href="https://explorelogy.lk/"
                    target="_blank"
                    className="hover:underline"
                  >
                    Explorelogy.
                  </a>
                </div>
                <div className="text-xs hover:underline cursor-pointer">
                  Privacy
                </div>
              </div>
            </div>
            <div className="flex md:justify-start justify-center gap-10">
              <div className="text-xs hover:underline cursor-pointer">
                Facebook
              </div>
              <div className="text-xs hover:underline cursor-pointer">
                Instagram
              </div>
              <div className="text-xs hover:underline cursor-pointer">
                Youtube
              </div>
              <div className="text-xs hover:underline cursor-pointer">
                Twitter
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Footer
