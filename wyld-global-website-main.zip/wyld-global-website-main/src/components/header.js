import * as React from "react"
import PropTypes from "prop-types"
import { Link } from "gatsby"
import Button from "./elements/button"
import { StaticImage } from "gatsby-plugin-image"
import $ from "jquery"
import { MenuIcon, XIcon } from "@heroicons/react/solid"
import { useState } from "react"

const Header = () => {
  const [scrolled, setScrolled] = useState(false)
  const [active, setActive] = useState(false)

  React.useEffect(() => {
    $(window).on("scroll", function () {
      if ($(this).scrollTop() > 100) {
        setScrolled(true)
      } else {
        setScrolled(false)
      }
    })
  })

  return (
    <div>
      <div
        className={
          scrolled
            ? "fixed w-full bg-white shadow-lg z-50 duration-500 "
            : "fixed w-full bg-white z-50 duration-500"
        }
      >
        <div className="container mx-auto px-10 ">
          <div className="items-center justify-between py-2 lg:flex hidden">
            <div>
              <Link to="/">
                <StaticImage
                  src="../images/brand/logo.png"
                  alt="wyld global"
                  className="w-32 cursor-pointer"
                />
              </Link>
            </div>
            <div className="flex items-center gap-20">
              <Link to="/work">
                <div className="cursor-pointer border-y-2 border-t-transparent duration-200 border-b-transparent px-2 hover:border-b-black">
                  Work
                </div>
              </Link>
              <Link to="/about">
                <div className="cursor-pointer border-y-2 border-t-transparent duration-200 border-b-transparent px-2 hover:border-b-black">
                  About
                </div>
              </Link>
              <Link to="/blog">
                <div className="cursor-pointer border-y-2 border-t-transparent duration-200 border-b-transparent px-2 hover:border-b-black">
                  Blog
                </div>
              </Link>

              <div className="ml-2">
                <Button title="Contact" link="/" />
              </div>
            </div>
          </div>
          <div className="flex items-center justify-between py-2 z-10 relative lg:hidden">
            <div>
              <Link to="/">
                <StaticImage
                  src="../images/brand/logo.png"
                  alt="wyld global"
                  className="w-28 cursor-pointer"
                />
              </Link>
            </div>
            <div className="flex items-center gap-20">
              {active ? (
                <XIcon className="w-7" onClick={() => setActive(false)} />
              ) : (
                <MenuIcon className="w-7" onClick={() => setActive(true)} />
              )}
            </div>
          </div>
        </div>
      </div>
      <div
        className={
          active
            ? "w-full bg-white py-10 mt-0 fixed z-10 top-14 px-10 duration-200 shadow-lg"
            : "w-full bg-white py-10 -mt-80 fixed z-10 top-14 px-10 duration-200 shadow-lg"
        }
      >
        <Link to="/work">
          <div
            className="cursor-pointer duration-200 mb-5"
            onClick={() => setActive(false)}
          >
            Work
          </div>
        </Link>
        <Link to="/about">
          <div
            className="cursor-pointer duration-200 mb-5"
            onClick={() => setActive(false)}
          >
            About
          </div>
        </Link>
        <Link to="/blog">
          <div
            className="cursor-pointer duration-200 mb-5"
            onClick={() => setActive(false)}
          >
            Blog
          </div>
        </Link>

        <Link to="/">
          <div
            className="cursor-pointer duration-200"
            onClick={() => setActive(false)}
          >
            Contact
          </div>
        </Link>
      </div>
    </div>
  )
}

export default Header
