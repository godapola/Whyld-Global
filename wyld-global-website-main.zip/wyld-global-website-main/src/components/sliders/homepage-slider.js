// import Swiper core and required modules
import React from "react"
import BackgroundImage from "gatsby-background-image"
import Button from "../elements/button"

import { Navigation, Pagination, Scrollbar, A11y } from "swiper"

import { Swiper, SwiperSlide } from "swiper/react"

// Import Swiper styles
import "swiper/css"
import "swiper/css/navigation"
import "swiper/css/pagination"
import "swiper/css/scrollbar"
import { Autoplay } from "swiper"

const HomepageSlider = props => {
  return (
    <Swiper
      // install Swiper modules
      modules={[Navigation, Pagination, Scrollbar, A11y, Autoplay]}
      slidesPerView={1.5}
      centeredSlides={true}
      navigation={true}
      loop={true}
      breakpoints={{
        1024: {
          slidesPerView: 1.5,
          spaceBetween: 20,
        },
        768: {
          slidesPerView: 1.5,
          spaceBetween: 20,
        },
        640: {
          slidesPerView: 1.5,
          spaceBetween: 12,
        },

        0: {
          slidesPerView: 1,
          spaceBetween: 12,
        },
      }}
      //   pagination={{ clickable: true }}
    >
      <div>
        {props.slider_array.map((item, index) => {
          return (
            <SwiperSlide key={index}>
              {({ isActive }) => (
                <div>
                  {isActive ? (
                    <div className=" overflow-hidden rounded-3xl mx-auto ">
                      <BackgroundImage
                        {...item.image}
                        className="py-24 sm:py-28 md:py-32 lg:py-44 xl:py-64 relative  "
                      >
                        <div className="absolute bottom-0 w-full lg:text-base text-sm">
                          <div className="flex sm:flex-row flex-col sm:justify-between px-5 lg:px-10 sm:items-center mb-3 lg:mb-8 ">
                            <div>
                              <div className="flex gap-5 lg:gap-10 text-lg text-white">
                                <div className="font-semibold lg:text-base text-sm">
                                  {item.topic}
                                </div>
                                <div className="font-light lg:text-base text-sm">
                                  {item.desc}
                                </div>
                              </div>
                            </div>

                            <div className="lg:text-base text-sm sm:block hidden">
                              <Button title="Learn More" filledWhite />
                            </div>
                          </div>
                        </div>
                      </BackgroundImage>
                    </div>
                  ) : (
                    <div className=" overflow-hidden rounded-3xl mx-auto   ">
                      <BackgroundImage
                        {...item.image}
                        className="py-24 sm:py-28 md:py-32 lg:py-44 xl:py-64  relative  "
                      >
                        <div className="bg-black/50  w-full h-full absolute top-0 "></div>
                      </BackgroundImage>
                    </div>
                  )}
                </div>
              )}
            </SwiperSlide>
          )
        })}
      </div>
    </Swiper>
  )
}

export default HomepageSlider
