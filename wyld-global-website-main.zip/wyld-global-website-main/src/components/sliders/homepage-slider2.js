// import Swiper core and required modules
import React from "react"
import BackgroundImage from "gatsby-background-image"
import Button from "../elements/button"

import { Navigation, Pagination, Scrollbar, A11y } from "swiper"

import { Swiper, SwiperSlide } from "swiper/react"
import { Autoplay } from "swiper"
import { useState, useEffect } from "react"
import $ from "jquery"

// Import Swiper styles
import "swiper/css"
import "swiper/css/navigation"
import "swiper/css/pagination"
import "swiper/css/scrollbar"

const HomepageSlider2 = props => {
  const [speed, setSpeed] = useState(0)
  const [speed2, setSpeed2] = useState(0)

  useEffect(() => {
    $(".swiper-wrapper").on({
      mouseenter: function () {
        props.slider2 ? setSpeed(3000) : setSpeed(5000)
      },
      mouseleave: function () {
        props.slider2 ? setSpeed(1000) : setSpeed(3000)
      },
    })
  })
  return (
    <Swiper
      // install Swiper modules
      modules={[Navigation, Pagination, Scrollbar, A11y, Autoplay]}
      spaceBetween={20}
      slidesPerView={4}
      autoplay={{
        delay: 0,
        disableOnInteraction: false,
      }}
      speed={speed}
      //   freeMode={true}
      //   freeModeMomentum={false}
      //   grabCursor={true}
      //   centeredSlides={true}
      //   navigation={true}
      loop={true}
      //   pagination={{ clickable: true }}
      //   onSwiper={swiper => console.log(swiper)}
      //   onSlideChange={() => console.log("slide change")}
    >
      <div>
        {props.slider_array.map((item, index) => {
          return (
            <div key={index} className="swiper-wrapper">
              <div>
                <SwiperSlide>
                  <div
                    className=" overflow-hidden rounded-3xl mx-auto   "
                    //   onMouseOver={() => {
                    //     setSpeed(3000)
                    //   }}
                    //   onMouseOut={() => {
                    //     setSpeed(1000)
                    //   }}
                  >
                    <BackgroundImage
                      {...item.image}
                      className="py-32 bg-cover  "
                    ></BackgroundImage>
                  </div>
                </SwiperSlide>
              </div>
            </div>
          )
        })}
      </div>
    </Swiper>
  )
}

export default HomepageSlider2
