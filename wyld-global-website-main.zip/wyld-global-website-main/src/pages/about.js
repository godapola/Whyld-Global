import * as React from "react"
import { Link } from "gatsby"
import { StaticImage } from "gatsby-plugin-image"
import { graphql } from "gatsby"
import { getImage, GatsbyImage } from "gatsby-plugin-image"
import { XIcon } from "@heroicons/react/outline"
import { convertToBgImage } from "gbimage-bridge"
import BackgroundImage from "gatsby-background-image"

import Layout from "../components/layout"
import Seo from "../components/seo"
import Button from "../components/elements/button"
import HomepageSlider from "../components/sliders/homepage-slider"
import HomepageSlider2 from "../components/sliders/homepage-slider2"
import Marquee from "react-fast-marquee"
import { useState, useEffect } from "react"
import { PlayIcon } from "@heroicons/react/outline"
import { PauseIcon } from "@heroicons/react/outline"
import $ from "jquery"

const About = ({ data }) => {
  const images = {
    header1: convertToBgImage(getImage(data.header)),

    header: getImage(data.header),
    p1: getImage(data.p1),
    p3: getImage(data.p3),
    p2: getImage(data.p2),
    p4: getImage(data.p4),
    p5: getImage(data.p5),
    team1: getImage(data.team1),
    team1bg: convertToBgImage(getImage(data.team1)),
    th_logo1: getImage(data.th_logo1),
    th_logo2: getImage(data.th_logo2),
    th_logo3: getImage(data.th_logo3),
    th_logo4: getImage(data.th_logo4),
    th_logo5: getImage(data.th_logo5),
    networkBg: convertToBgImage(getImage(data.networkBg)),
    networkBg: getImage(data.networkBg),
    bg: convertToBgImage(getImage(data.bg)),
    bg: getImage(data.bg),
  }

  const partners = [
    {
      image: images.p3,
    },
    {
      image: images.p1,
    },
    {
      image: images.p1,
    },
    {
      image: images.p2,
    },
    {
      image: images.p4,
    },

    {
      image: images.p5,
    },
    {
      image: images.p1,
    },
    {
      image: images.p2,
    },
    {
      image: images.p5,
    },
    {
      image: images.p1,
    },
    {
      image: images.p4,
    },
    {
      image: images.p3,
    },
  ]

  const team = [
    {
      image: images.team1,
      name: " Banura Sooriyapperuma",
      position: "Co-Founder / Chief Executive Officer",
      dec: "In West Philadelphia, born and raised… Banura spent his early days curating visual displays. He went on to merchandise some of Philadelphia’s finest props and antiques before embarking on a 10+ year career in Arts Education. Banura defines what it means to be both artist and educator. Equipped with a BFA from the University of The Arts and years of dealing with the art and practice of creating strong visual content, he now manages and directs the vision and the voice of Philly Reps.",
    },
    {
      image: images.team1,
      name: " Shanellie White",
      position: "Co-Founder / Chief Creative Officer",
      dec: "Shanellie is a Philadelphia based Creative Consultant with an extensive background in commercial photography, education and consulting. She's worked with hundreds of photographers from all parts of the globe during her time in the industry. She holds an MPS in Digital Photography from The School of Visual Arts and a BFA in Photography from Parsons School of Design.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et ",
    },
    {
      image: images.team1,
      name: " Dilanjan Seneviratne",
      position: "Co-Founder / Chief Strategy Officer",
      dec: "Dilanjan has been working in the photography industry for over 8 years, honing his vision and his skills as both a photographer/photographer's assistant for clients in the hospitality, architecture, and education industry. After working closely with Stacy Swiderski as his Assistant Photo Editor at Stacy Swiderski Consulting, Allie has been instrumental in the development and launch of Philly Reps. She works with photographers on creative coaching, portfolio builds and project development. ",
    },
    {
      image: images.team1,
      name: " Theruni Galagedara",
      position: "Lead Strategist - Outright Global",
      dec: "Theruni is a Philadelphia based Creative Consultant with an extensive background in commercial photography, education and consulting. She's worked with hundreds of photographers from all parts of the globe during her time in the industry. She holds an MPS in Digital Photography from The School of Visual Arts and a BFA in Photography from Parsons School of Design.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et ",
    },
    {
      image: images.team1,
      name: " Prithvi Jegarajasingam",
      position: "Head of Production - Burketch Media House",
      dec: "pavithri is a Philadelphia based Creative Consultant with an extensive background in commercial photography, education and consulting. She's worked with hundreds of photographers from all parts of the globe during her time in the industry. She holds an MPS in Digital Photography from The School of Visual Arts and a BFA in Photography from Parsons School of Design.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et ",
    },

    {
      image: images.team1,
      name: " Shehan Tharaka",
      position: "Producer - Theewra Worldwide",
      dec: "Shehan has been working in the photography industry for over 8 years, honing his vision and his skills as both a photographer/photographer's assistant for clients in the hospitality, architecture, and education industry. After working closely with Stacy Swiderski as his Assistant Photo Editor at Stacy Swiderski Consulting, Allie has been instrumental in the development and launch of Philly Reps. She works with photographers on creative coaching, portfolio builds and project development. ",
    },
    {
      image: images.team1,
      name: " Kavinda Siriwardhana",
      position: "Art Director",
      dec: "In West Philadelphia, born and raised… Kavinda spent his early days curating visual displays. He went on to merchandise some of Philadelphia’s finest props and antiques before embarking on a 10+ year career in Arts Education.Kavinda defines what it means to be both artist and educator. Equipped with a BFA from the University of The Arts and years of dealing with the art and practice of creating strong visual content, he now manages and directs the vision and the voice",
    },
    {
      image: images.team1,
      name: " Himaaya X",
      position: "Business / Customer Strategy Lead",
      dec: "Himaya is a Philadelphia based Creative Consultant with an extensive background in commercial photography, education and consulting. She's worked with hundreds of photographers from all parts of the globe during her time in the industry. She holds an MPS in Digital Photography from The School of Visual Arts and a BFA in Photography from Parsons School of Design.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et ",
    },
    {
      image: images.team1,
      name: " John Doe",
      position: "Team Hero",
      dec: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum",
    },
  ]
  const network = [
    {
      image: images.th_logo1,
      dec: "Unique brand interactions online that spark imaginations and create conversations.",
    },

    {
      image: images.th_logo2,

      dec: "Unique brand interactions online that spark imaginations and create conversations.",
    },

    {
      image: images.th_logo3,

      dec: "Unique brand interactions online that spark imaginations and create conversations.",
    },
    {
      image: images.th_logo4,

      dec: "Unique brand interactions online that spark imaginations and create conversations.",
    },
    {
      image: images.th_logo5,

      dec: "Unique brand interactions online that spark imaginations and create conversations.",
    },
  ]

  const [popUp, setPopUp] = useState(false)
  const [activeIndex, setActiveIndex] = useState()
  const selectedItem = team[activeIndex]

  return (
    <Layout>
      <Seo title="About" />
      <section>
        <div className="relative">
          <div className="absolute inset-0 left-10 flex items-center">
            <GatsbyImage image={images.networkBg} className="w-6/12" />
          </div>
          <div className="container mx-auto px-10  pb-24    relative">
            <div className="flex flex-col lg:flex-row  lg:h-screen items-center justify-between  lg:gap-10 xl:gap-40 md:relative">
              <div>
                <div className="text-6xl mt-40 lg:mt-0 md:text-8xl font-extrabold">
                  #itsWyld
                </div>

                <div className=" mt-14 mb-14 lg:mb-0 lg:mt-20  text-2xl font-bold text-center lgtext-right">
                  Our story
                </div>
              </div>
              <div>
                <div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 justify-center border-2 border-dark-gray py-5  rounded-3xl text-center">
                    <div>
                      <div className="font-bold text-xl">8000+</div>
                      <div>Projects Done</div>
                    </div>
                    <div>
                      <div className="font-bold text-xl">500+</div>
                      <div>Client base </div>
                    </div>
                    <div>
                      <div className="font-bold text-xl">50+</div>
                      <div>countries</div>
                    </div>
                    <div>
                      <div className="font-bold text-xl">10+</div>
                      <div>Awards won</div>
                    </div>
                  </div>
                </div>
                <div className="mt-20 ">
                  In good times and bad, we partner with good brands to achieve
                  meaningful progress. In a world of complexity, we offer
                  simplicity through consistent, world-class services and
                  integrated solutions. Our mission is to create wild
                  relationships with good brands and their customers. Our
                  culture inspires people. Inspired people create unusual work.
                  Unusual work creates wild relationships.{" "}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div className="bg-secondary-dark   ">
          <div className="container mx-auto  px-10  py-24 ">
            <div>
              <div className="text-3xl font-bold text-white text-center mb-14 ">
                Friends & partners
              </div>
              <div className="flex flex-wrap justify-center  gap-14 ">
                {partners.map((item, index) => {
                  return (
                    <div
                      className="flex items-center justify-center"
                      key={index}
                    >
                      <GatsbyImage image={item.image} className="w-40" />
                    </div>
                  )
                })}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section>
        <div className="container mx-auto px-10 py-24   ">
          <div className="text-3xl font-semibold mb-14 ">Meet the team</div>
          <div className="grid  sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 ">
            {team.map((item, index) => {
              return (
                <div
                  key={index}
                  onClick={() => {
                    setPopUp(true)
                    setActiveIndex(index)
                  }}
                >
                  <div className="group hover:cursor-pointer">
                    <div className="">
                      <div className="overflow-hidden  rounded-3xl">
                        <BackgroundImage
                          {...images.team1bg}
                          className="w-full rounded-3xl group-hover:scale-110 duration-500 py-40 "
                        />
                      </div>
                    </div>
                    <div className="mt-4 mb-4">
                      <div className=" font-semibold text-xl">{item.name}</div>
                      <div className="mt-1">{item.position}</div>
                      {/* <div className="mt-4">{item.dec}</div> */}
                    </div>
                  </div>
                </div>
              )
            })}

            {popUp && (
              <>
                <div className="top-0 left-0 z-50 fixed w-full h-screen">
                  <div className="w-full h-screen flex justify-center bg-black/50 items-center">
                    <div className="bg-primary-bg w-full ">
                      <div>
                        <BackgroundImage
                          {...images.team1bg}
                          className="bg-cover w-full h-full  overflow-hidden relative "
                        >
                          <div
                            className="cursor-pointer absolute top-0 right-0 mr-5 mt-5"
                            onClick={() => setPopUp(false)}
                          >
                            <XIcon
                              width={30}
                              className="hover:rotate-90 duration-200 text-white"
                            />
                          </div>
                          <div className="bg-black/50 w-full h-screen flex md:items-center items-start md:pt-0 pt-24 ">
                            <div className="container mx-auto px-10 text-white">
                              <div className="md:text-3xl text-2xl font-semibold lg:max-w-[20px] lg:text-left text-center ">
                                {selectedItem.name}
                              </div>
                              <div className="lg:text-left text-center md:text-base text-xs">
                                {selectedItem.position}
                              </div>

                              <div className="pt-10 lg:max-w-xl max-w-none lg:text-left text-center md:text-xl text-base">
                                {selectedItem.dec}
                              </div>
                              <div className="pt-4 lg:max-w-xl max-w-none lg:text-left text-center md:text-xl text-base">
                                Lorem ipsum dolor sit amet consectetur
                                adipisicing elit. Nostrum sequi eum deserunt
                                minimaLorem ipsum dolor sit amet consectetur
                                adipisicing elit. Nostrum sequi eum deserunt
                                minimal
                              </div>
                              <div className="pt-10 flex lg:max-w-xl max-w-none md:gap-6 gap-3 lg:justify-start justify-center md:text-base text-xs">
                                <div className="cursor-pointer">
                                  Connect with Dilanjan
                                </div>
                                <div className="cursor-pointer">LinkedIn</div>
                                <div className="cursor-pointer">Web</div>
                                <div className="cursor-pointer">Instagram</div>
                              </div>
                            </div>
                          </div>
                        </BackgroundImage>
                      </div>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </section>
      <section>
        <div className="bg-light-gray relative">
          <GatsbyImage
            image={images.networkBg}
            className="w-2/5 absolute top-0 left-0"
          />
          <div className="container mx-auto px-10  py-24 relative">
            <div className="">
              <div className="text-3xl font-semibold mb-14">Our Network</div>
              <div className="">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris
                nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor
                in reprehenderit in voluptate velit esse cillum dolore eu fugiat
                nulla pariatur. Excepteur sint occaecat cupidatat non proident,
                sunt in culpa qui officia deserunt mollit anim id est laborum
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4 ">
                {network.map((item, index) => {
                  return (
                    <div key={index}>
                      <div className="bg-white p-6 mt-10 rounded-3xl opacity-70 ">
                        <div className="w-2/4">
                          <GatsbyImage image={item.image} />
                        </div>
                        <div className=" pt-10 ">{item.dec}</div>
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  )
}

export const query = graphql`
  query AboutImages {
    header: file(relativePath: { eq: "homepage/header.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    p1: file(relativePath: { eq: "aboutpage/p1.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    p3: file(relativePath: { eq: "aboutpage/p3.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    p2: file(relativePath: { eq: "aboutpage/p2.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    p5: file(relativePath: { eq: "aboutpage/p5.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    p4: file(relativePath: { eq: "aboutpage/p4.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    team1: file(relativePath: { eq: "aboutpage/team1.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    th_logo1: file(relativePath: { eq: "aboutpage/th_logo1.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    th_logo2: file(relativePath: { eq: "aboutpage/th_logo2.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    th_logo3: file(relativePath: { eq: "aboutpage/th_logo3.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    th_logo4: file(relativePath: { eq: "aboutpage/th_logo4.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    th_logo5: file(relativePath: { eq: "aboutpage/th_logo5.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    networkBg: file(relativePath: { eq: "aboutpage/networkBg.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    bg: file(relativePath: { eq: "aboutpage/bg.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
  }
`

export default About
