import * as React from "react"
import { Link } from "gatsby"
import { StaticImage } from "gatsby-plugin-image"
import { graphql } from "gatsby"
import { getImage, GatsbyImage } from "gatsby-plugin-image"

import { convertToBgImage } from "gbimage-bridge"
import BackgroundImage from "gatsby-background-image"

import Layout from "../components/layout"
import Seo from "../components/seo"
import Button from "../components/elements/button"

const Blog = ({ data }) => {
  const images = {
    // header: convertToBgImage(getImage(data.header)),
    // interstellar: convertToBgImage(getImage(data.interstellar)),
    //video: getImage(data.video),
    //image1: getImage(data.image1),
    featured: getImage(data.featured),

    blogfeatured1: getImage(data.blogfeatured1),
    blogfeatured2: getImage(data.blogfeatured2),
    blogfeatured3: getImage(data.blogfeatured3),
    blogfeatured4: getImage(data.blogfeatured4),
    blogfeatured5: getImage(data.blogfeatured5),
    blogfeatured6: getImage(data.blogfeatured6),
    blogfeatured7: getImage(data.blogfeatured7),
    blogfeatured8: getImage(data.blogfeatured8),
    blogfeatured9: getImage(data.blogfeatured9),
    blogfeatured10: getImage(data.blogfeatured10),
    blogfeatured11: getImage(data.blogfeatured11),
    blogfeatured12: getImage(data.blogfeatured12),
  }

  const blogpost = [
    {
      image: images.blogfeatured1,
      categoryname: "Category name",
      title: "10 photography tips up your product photography",
      articleby: "John Doe",
      postdate: "November 24 2022",
    },
    {
      image: images.blogfeatured2,
      categoryname: "Category name",
      title: "Shoot that you’ll never ever forget",
      articleby: "John Doe",
      postdate: "November 24 2022",
    },
    {
      image: images.blogfeatured3,
      categoryname: "Category name",
      title: "10 photography tips up your product photography",
      articleby: "John Doe",
      postdate: "November 24 2022",
    },

    {
      image: images.blogfeatured4,
      categoryname: "Category name",
      title: "10 Crucial Makeup Photography Tips",
      articleby: "John Doe",
      postdate: "November 24 2022",
    },

    {
      image: images.blogfeatured5,
      categoryname: "Category name",
      title: "Shoot that you’ll never ever forget",
      articleby: "John Doe",
      postdate: "November 24 2022",
    },

    {
      image: images.blogfeatured6,
      categoryname: "Category name",
      title: "Shoot that you’ll never ever forget",
      articleby: "John Doe",
      postdate: "November 24 2022",
    },
  ]

  const blogpost2 = [
    {
      image: images.blogfeatured7,
      categoryname: "Category name",
      title: "Shoot that you’ll never ever forget",
      articleby: "John Doe",
      postdate: "November 24 2022",
    },

    {
      image: images.blogfeatured8,
      categoryname: "Category name",
      title: "10 photography tips up your product photography",
      articleby: "John Doe",
      postdate: "November 24 2022",
    },

    {
      image: images.blogfeatured9,
      categoryname: "Category name",
      title: "10 photography tips up your product photography",
      articleby: "John Doe",
      postdate: "November 24 2022",
    },

    {
      image: images.blogfeatured10,
      categoryname: "Category name",
      title: "10 Crucial Makeup Photography Tips",
      articleby: "John Doe",
      postdate: "November 24 2022",
    },

    {
      image: images.blogfeatured11,
      categoryname: "Category name",
      title: "Shoot that you’ll never ever forget",
      articleby: "John Doe",
      postdate: "November 24 2022",
    },

    {
      image: images.blogfeatured12,
      categoryname: "Category name",
      title: "Shoot that you’ll never ever forget",
      articleby: "John Doe",
      postdate: "November 24 2022",
    },
  ]

  return (
    <Layout>
      <Seo title="Blog" />

      <section>
        <div className="container mx-auto px-10 py-24">
          <div className="text-3xl	font-bold	mb-4"> Featured </div>

          <div class="grid grid-cols-1 gap-6">
            {/* Item row */}
            <div className="shadow-lg pb-3 rounded-3xl	">
              <GatsbyImage
                image={images.featured}
                className="w-full rounded-3xl"
              />

              <div className="mx-6 border-b-2 pb-3  mb-3">
                <div className="text-sm  text-slate-400  font-normal  mt-4">
                  category name
                </div>

                <div className="text-xl	font-bold	mt-2  ">
                  Shoot that you’ll never ever forget
                </div>
              </div>

              <div class="grid grid-cols-2 mx-6">
                <div className=" text-slate-400  font-normal text-sm  text-left  mb-4">
                  By John Doe
                </div>
                <div className=" text-slate-400  font-normal text-sm  text-right  mb-4">
                  Novemvber 24 2022
                </div>
              </div>
            </div>
            {/* Item row END */}
          </div>
        </div>
      </section>
      <section>
        <div className="container mx-auto px-10">
          <div class="flex flex-col   overflow-x-auto scrollbar-hide xl:flex-row justify-between text-center  mt-12  mb-16  ">
            <div class="flex-none   bg-black	 text-white	  border  py-3 px-11  mr-2  rounded-3xl">
              all categories
            </div>
            <div class="flex-none  bg-dark-gray		 text-white	  border  py-3 px-11  mx-2  rounded-3xl">
              Photoshoot
            </div>
            <div class="flex-none  bg-dark-gray		 text-white	  border  py-3 px-11  mx-2  rounded-3xl">
              Music production
            </div>
            <div class="flex-none  bg-dark-gray		 text-white	  border  py-3 px-11  mx-2  rounded-3xl">
              Brand Identity
            </div>
            <div class="flex-none  bg-dark-gray		 text-white	  border  py-3 px-11  mx-2  rounded-3xl">
              Television Series
            </div>
            <div class="flex-none  bg-dark-gray		 text-white	  border  py-3 px-11  mx-2  rounded-3xl">
              category 06
            </div>
            <div class="flex-none  bg-dark-gray		 text-white	  border  py-3 px-11  mx-2  rounded-3xl">
              category 07
            </div>
            <div class="flex-none  bg-dark-gray		 text-white	  border  py-3 px-11  mx-2  rounded-3xl">
              category 07
            </div>
            <div class="flex-none  bg-dark-gray		 text-white	  border  py-3 px-11  mx-2  rounded-3xl">
              category 07
            </div>
          </div>
        </div>
      </section>
      <section>
        <div className="container mx-auto px-10 pb-24">
          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-16">
            {/* Item row */}
            {blogpost.map((post, index) => {
              return (
                <div className="shadow-lg pb-3 rounded-3xl	">
                  <GatsbyImage
                    image={post.image}
                    className="w-full rounded-3xl"
                  />
                  <div className="mx-6">
                    <div className=" border-b-2 pb-3 mb-3">
                      <div className="text-gray-400 text-light text-sm  mt-4">
                        {post.categoryname}
                      </div>

                      <div className="text-xl	font-bold	mt-2 ">{post.title}</div>
                    </div>
                    <div className="flex justify-between text-gray-400 text-light text-sm ">
                      <div>By {post.articleby}</div>
                      <div>{post.postdate}</div>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </section>

      <section className="bg-black">
        <div className="container mx-auto px-10 py-10">
          <div className="flex gap-10 items-center justify-between">
            <div className="w-full ">
              <form class="flex flex-row">
                <input
                  class="w-full focus:outline-none px-5 py-4 rounded-l-full "
                  type="text"
                  placeholder="Enter your Email. Get latest news and offers "
                />
                <span class="flex items-center bg-white rounded-r-full pr-2 cursor-pointer">
                  <Button title="Subscribe" className="" />
                </span>
              </form>
              {/* <input
                type="text"
                placeholder="Enter your Email. Get latest news and offers "
                className="w-full focus:outline-none px-5 py-3 rounded-full relative"
              />
              <Button title="Subscribe" className="absolute top-0" /> */}
            </div>
            <div className="">
              <div className="flex flex-col md:flex-row  py-4 ">
                <div className="px-5 text-white">Facebook</div>
                <div className="px-5 text-white">Instagram</div>
                <div className="px-5 text-white">YouTube</div>
                <div className="px-5 text-white">Twitter</div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div className="container mx-auto px-10 py-24">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-12">
            {blogpost2.map((post, index) => {
              return (
                <div className="shadow-lg pb-3 rounded-3xl	">
                  <GatsbyImage
                    image={post.image}
                    className="w-full rounded-3xl"
                  />
                  <div className="mx-6">
                    <div className=" border-b-2 pb-3 mb-3">
                      <div className="text-gray-400 text-light text-sm  mt-4">
                        category name
                      </div>

                      <div className="text-xl	font-bold	mt-2 ">
                        Shoot that you’ll never ever forget
                      </div>
                    </div>
                    <div className="flex justify-between text-gray-400 text-light text-sm ">
                      <div>By John Doe</div>
                      <div>November 24 2022</div>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
          <div className="grid justify-items-center pt-10">
            <div>
              <Button title="Load More" link="/" />
            </div>
          </div>
        </div>
      </section>
    </Layout>
  )
}
export const query = graphql`
  query blogpageImages {
    featured: file(relativePath: { eq: "blog/blog-feature-01.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    blogfeatured1: file(relativePath: { eq: "blog/blog1.jpg" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    blogfeatured2: file(relativePath: { eq: "blog/blog2.jpg" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    blogfeatured3: file(relativePath: { eq: "blog/blog3.jpg" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    blogfeatured4: file(relativePath: { eq: "blog/blog4.jpg" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    blogfeatured5: file(relativePath: { eq: "blog/blog5.jpg" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    blogfeatured6: file(relativePath: { eq: "blog/blog6.jpg" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    blogfeatured7: file(relativePath: { eq: "blog/blog7.jpg" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    blogfeatured8: file(relativePath: { eq: "blog/blog8.jpg" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    blogfeatured9: file(relativePath: { eq: "blog/blog9.jpg" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    blogfeatured10: file(relativePath: { eq: "blog/blog10.jpg" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    blogfeatured11: file(relativePath: { eq: "blog/blog11.jpg" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    blogfeatured12: file(relativePath: { eq: "blog/blog12.jpg" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
  }
`

export default Blog
