import * as React from "react"
import { Link } from "gatsby"
import { StaticImage } from "gatsby-plugin-image"
import { graphql } from "gatsby"
import { getImage, GatsbyImage } from "gatsby-plugin-image"

import { convertToBgImage } from "gbimage-bridge"
import BackgroundImage from "gatsby-background-image"

import Layout from "../components/layout"
import Seo from "../components/seo"
import Button from "../components/elements/button"
import SinglePage from "../components/aboutUs/single-page"

const Casestudy = ({ data }) => {
  const images = {
    header: convertToBgImage(getImage(data.header)),
    // interstellar: convertToBgImage(getImage(data.interstellar)),
    video: getImage(data.video),
    image1: getImage(data.image1),

    down1: getImage(data.down1),
    down2: getImage(data.down2),
    down3: getImage(data.down3),
    down4: getImage(data.down4),
    down5: getImage(data.down5),
    down6: getImage(data.down6),

    // Smailer Project

    smailer1: getImage(data.smailer1),
    smailer2: getImage(data.smailer2),
    smailer3: getImage(data.smailer3),
    smailer4: getImage(data.smailer4),
    smailer5: getImage(data.smailer5),
    smailer6: getImage(data.smailer6),
    smailer7: getImage(data.smailer7),
    smailer8: getImage(data.smailer8),
  }

  const socialIcons = [
    {
      icon: images.attach,
    },
    {
      icon: images.facebook,
    },
    {
      icon: images.twitter,
    },
    {
      icon: images.email,
    },
  ]

  const dec = [
    {
      title: "Client",
      category: "Royal Cahew Private Limited",
    },
    {
      title: "Agency",
      category: "Pettah Effect, Theewra",
    },
    {
      title: "Month, Year",
      category: "May, 2022",
    },
    {
      title: "Project Titile",
      category: "Moments Made Magical",
    },
    {
      title: "Catagory",
      category: "Strategy, Digital Marketing",
    },
  ]

  return (
    <Layout>
      <Seo title="Case Study" />

      <section>
        <BackgroundImage {...images.header}>
          <div className="container mx-auto px-10  pb-8">
            <div className="flex h-screen items-end ">
              <div className=" pb-20">
                <div className="mt-4 text-xl font-bold">#Project Titile</div>
                <div className="text-6xl sm:text-8xl font-bold">
                  #Client Name
                </div>
              </div>
            </div>
          </div>
        </BackgroundImage>
      </section>

      <section>
        <div className="container mx-auto px-10 pt-24">
          <div class="grid grid-cols-1  lg:grid-cols-2 gap-10">
            <div className=" col-span-1">
              <div className="  ">
                {dec.map((item, index) => {
                  return (
                    <div key={index}>
                      <div className=" ">
                        <div className="">
                          <div className="flex gap-20 ">
                            <div className="font-semibold	text-base	mb-4">
                              {item.title}
                            </div>
                            <div className="text-base	mb-4 ">
                              {item.category}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>

            <div>
              <div className="font-bold	text-base	mb-6">Client</div>

              <div className="text-base">
                Everybody’s making NFTs these days but we thought it was kinda
                weird that people are paying millions of dollars for something
                you can only enjoy with your eyes. That’s why we created the
                World’s First Smellable NFT for Old Spice.{" "}
              </div>
              <div className="text-base mb-6">
                During a two hour livestream on Twitch, nearly 25k streamers
                helped six artists to craft this majestic digital masterpiece
                through tens of thousands of comments{" "}
              </div>

              <div className="text-base">
                Everybody’s making NFTs these days but we thought it was kinda
                weird that people are paying millions of dollars for something
                you can only enjoy with your eyes. That’s why we created the
                World’s First Smellable NFT for Old Spice.{" "}
              </div>
              <div className="text-base mb-6">
                During a two hour livestream on Twitch, nearly 25k streamers
                helped six artists to craft this majestic digital masterpiece
                through tens of thousands of comments{" "}
              </div>

              <div className="text-base">
                Everybody’s making NFTs these days but we thought it was kinda
                weird that people are paying millions of dollars for something
                you can only enjoy with your eyes. That’s why we created the
                World’s First Smellable NFT for Old Spice.{" "}
              </div>

              <div className="text-base mb-6">
                During a two hour livestream on Twitch, nearly 25k streamers
                helped six artists to craft this majestic digital masterpiece
                through tens of thousands of comments{" "}
              </div>

              <div className="text-base">
                Everybody’s making NFTs these days but we thought it was kinda
                weird that people are paying millions of dollars for something
                you can only enjoy with your eyes. That’s why we created the
                World’s First Smellable NFT for Old Spice.{" "}
              </div>
              <div className="text-base mb-6">
                During a two hour livestream on Twitch, nearly 25k streamers
                helped six artists to craft this majestic digital masterpiece
                through tens of thousands of comments{" "}
              </div>

              <div className="text-base">
                Everybody’s making NFTs these days but we thought it was kinda
                weird that people are paying millions of dollars for something
                you can only enjoy with your eyes. That’s why we created the
                World’s First Smellable NFT for Old Spice.{" "}
              </div>
              <div className="text-base mb-6">
                During a two hour livestream on Twitch, nearly 25k streamers
                helped six artists to craft this majestic digital masterpiece
                through tens of thousands of comments{" "}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section>
        <div className="py-24">
          <div>
            <SinglePage />
          </div>
        </div>
      </section>

      <section>
        <div className="container mx-auto px-10 pb-24">
          <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <GatsbyImage image={images.down1} className="w-full" />
            </div>
            <div>
              <GatsbyImage image={images.down2} className="w-full" />
            </div>
            <div>
              <GatsbyImage image={images.down3} className="w-full" />
            </div>
            <div>
              <GatsbyImage image={images.down4} className="w-full" />
            </div>
            <div>
              <GatsbyImage image={images.down5} className="w-full" />
            </div>
            <div>
              <GatsbyImage image={images.down6} className="w-full" />
            </div>
          </div>
        </div>
      </section>

      <section className="bg-light-gray">
        <div className="container mx-auto px-10 py-10">
          <div class="grid grid-cols-3 gap-4">
            <div className="font-bold	text-base	"> Share Our Work </div>
          </div>
        </div>
      </section>

      <section>
        <div className="container mx-auto px-10 py-24">
          <div className="text-3xl	font-bold	mb-14"> Similar Projects </div>

          <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3  xl:grid-cols-4 gap-6  gap-y-14">
            {/* Item row */}
            <div className="shadow-lg pb-3 rounded-3xl	">
              <GatsbyImage
                image={images.smailer1}
                className="w-full rounded-3xl"
              />

              <div className="text-base	font-bold px-6	pt-4">Rawwath dasin</div>
              <div className="text-base	 font-normal	px-6	"> Yohani Diloka</div>
            </div>
            {/* Item row END */}

            {/* Item row */}
            <div className="shadow-lg pb-3 rounded-3xl	">
              <GatsbyImage
                image={images.smailer2}
                className="w-full rounded-3xl"
              />

              <div className="text-base	font-bold px-6	pt-4">
                {" "}
                Tropical beverages{" "}
              </div>
              <div className="text-base	 font-normal	px-6	"> Wichy coconut </div>
            </div>
            {/* Item row END */}

            {/* Item row */}
            <div className="shadow-lg pb-3 rounded-3xl	">
              <GatsbyImage
                image={images.smailer3}
                className="w-full rounded-3xl"
              />

              <div className="text-base	font-bold px-6	pt-4"> band Campain </div>
              <div className="text-base	 font-normal	px-6	"> Nations Trust </div>
            </div>
            {/* Item row END */}

            {/* Item row */}
            <div className="shadow-lg pb-3 rounded-3xl	">
              <GatsbyImage
                image={images.smailer4}
                className="w-full rounded-3xl"
              />

              <div className="text-base	font-bold px-6	pt-4">
                {" "}
                prehistoric planet{" "}
              </div>
              <div className="text-base	 font-normal	px-6	"> apple tV </div>
            </div>
            {/* Item row END */}

            {/* Item row */}
            <div className="shadow-lg pb-3 rounded-3xl	">
              <GatsbyImage
                image={images.smailer5}
                className="w-full rounded-3xl"
              />

              <div className="text-base	font-bold px-6	pt-4"> Swan song </div>
              <div className="text-base	 font-normal	px-6	"> Apple tV </div>
            </div>
            {/* Item row END */}

            {/* Item row */}
            <div className="shadow-lg pb-3 rounded-3xl	">
              <GatsbyImage
                image={images.smailer6}
                className="w-full rounded-3xl"
              />

              <div className="text-base	font-bold px-6	pt-4">
                {" "}
                Gem Photoshoot{" "}
              </div>
              <div className="text-base	 font-normal	px-6	"> Punsiri gems </div>
            </div>
            {/* Item row END */}

            {/* Item row */}
            <div className="shadow-lg pb-3 rounded-3xl	">
              <GatsbyImage
                image={images.smailer7}
                className="w-full rounded-3xl"
              />

              <div className="text-base	font-bold px-6	pt-4">
                {" "}
                Shannara Chronicals{" "}
              </div>
              <div className="text-base	 font-normal	px-6	"> ABC television </div>
            </div>
            {/* Item row END */}

            {/* Item row */}
            <div className="shadow-lg pb-3 rounded-3xl	">
              <GatsbyImage
                image={images.smailer8}
                className="w-full rounded-3xl"
              />

              <div className="text-base	font-bold px-6	pt-4">
                {" "}
                Discovery of Witches{" "}
              </div>
              <div className="text-base	 font-normal	px-6	"> Sky orginal </div>
            </div>
            {/* Item row END */}
          </div>
        </div>
      </section>

      {/* <section>
        <div className="container mx-auto px-10 pb-24  ">
          <div className="text-xl font-semibold mb-14">Featured Projects</div>
          <div className=" overflow-hidden rounded-3xl  ">
            <BackgroundImage
              {...images.interstellar}
              className="py-64 relative "
            >
              <div className="absolute bottom-0 w-full">
                <div className="flex justify-between px-10 items-center mb-10 font-semibold">
                  <div className="flex gap-10 text-lg">
                    <div>Drama</div>
                    <div>Client/Brand Name</div>
                  </div>

                  <div>
                    <Button title="Learn More" filled />
                  </div>
                </div>
              </div>
            </BackgroundImage>
          </div>
        </div>
      </section> */}
    </Layout>
  )
}
export const query = graphql`
  query casestudypageImages {
    header: file(relativePath: { eq: "casestudypage/header.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    video: file(relativePath: { eq: "casestudypage/Video.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    image1: file(relativePath: { eq: "casestudypage/image-1.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    down1: file(relativePath: { eq: "casestudypage/down1.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    down2: file(relativePath: { eq: "casestudypage/down2.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    down3: file(relativePath: { eq: "casestudypage/down3.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    down4: file(relativePath: { eq: "casestudypage/down4.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    down5: file(relativePath: { eq: "casestudypage/down5.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    down6: file(relativePath: { eq: "casestudypage/down6.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    smailer1: file(relativePath: { eq: "casestudypage/smailproject1.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    smailer2: file(relativePath: { eq: "casestudypage/smailproject2.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    smailer3: file(relativePath: { eq: "casestudypage/smailproject3.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    smailer4: file(relativePath: { eq: "casestudypage/smailproject4.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    smailer5: file(relativePath: { eq: "casestudypage/smailproject5.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    smailer6: file(relativePath: { eq: "casestudypage/smailproject6.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    smailer7: file(relativePath: { eq: "casestudypage/smailproject7.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    smailer8: file(relativePath: { eq: "casestudypage/smailproject8.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
  }
`

export default Casestudy
