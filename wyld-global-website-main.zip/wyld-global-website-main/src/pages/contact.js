import React from "react"
import Layout from "../components/layout"

import { graphql } from "gatsby"
import { getImage, GatsbyImage } from "gatsby-plugin-image"

import Seo from "../components/seo"
import Button from "../components/elements/button"

import { useState, useEffect } from "react"

import {} from "@heroicons/react/outline"

const Contact = ({ data }) => {
  const [active, setActive] = useState(0)
  const images = {
    header: getImage(data.header),
  }
  return (
    <Layout>
      <Seo title="Home" />
      <div className="container mx-auto px-10  ">
        <div className="flex h-screen items-center ">
          <div>
            <div className="text-6xl font-extrabold">
              Let's make your dreams come true
            </div>
            <div className="mt-4 text-xl ">
              Contact us or start a project, we’ll get back to you soon
            </div>
            <div className="flex flex-wrap mt-4 cursor-pointer">
              <Button title="Start A Project " link={"/form"} />
            </div>
          </div>
          <div>
            <GatsbyImage image={images.header} className="w-full" />
          </div>
        </div>
      </div>
    </Layout>
  )
}
export const query = graphql`
  query ContactPageImages {
    interstellar: file(relativePath: { eq: "homepage/interstellar.jpg" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    header: file(relativePath: { eq: "homepage/header.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
  }
`
export default Contact
