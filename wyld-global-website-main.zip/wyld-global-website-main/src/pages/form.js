import { Link } from "gatsby"
import { StaticImage } from "gatsby-plugin-image"
import { graphql } from "gatsby"
import { getImage, GatsbyImage } from "gatsby-plugin-image"
import { ArrowNarrowRightIcon } from "@heroicons/react/solid"

import { convertToBgImage } from "gbimage-bridge"
import BackgroundImage from "gatsby-background-image"

import Layout from "../components/layout"
import Seo from "../components/seo"
import Button from "../components/elements/button"
import HomepageSlider from "../components/sliders/homepage-slider"
import HomepageSlider2 from "../components/sliders/homepage-slider2"
import Marquee from "react-fast-marquee"
import React, { useState, useCallback } from "react"
import { PlayIcon } from "@heroicons/react/outline"
import { PauseIcon } from "@heroicons/react/outline"
import { CheckCircleIcon } from "@heroicons/react/outline"
import { CloudUploadIcon } from "@heroicons/react/outline"
import { XCircleIcon } from "@heroicons/react/outline"
import { navigate } from "gatsby"

import $ from "jquery"
import { useMemo } from "react"
import { Range, getTrackBackground } from "react-range"

import { useDropzone } from "react-dropzone"
import { get } from "jquery"
import { min } from "moment-timezone"
import Labeled from "../components/contactus/thum"

import { useForm } from "react-hook-form"

import { yupResolver } from "@hookform/resolvers/yup"
import * as yup from "yup"
import Basic from "../components/contactus/upload"
import Uploader from "../components/contactus/upload"
import { Controller } from "swiper"
import { UserContext } from "../components/contactus/upload"
import Complexity from "../components/contactus/complexity"
import Sophistication from "../components/contactus/sophistication"
import TimeFrame from "../components/contactus/timeframe"

const Form = ({ data }, props) => {
  console.log(UserContext)
  const [user, setUser] = useState("Jesse Hall")

  const [file, setFile] = useState()
  const [value, setValue] = useState([50])
  const [active, setActive] = useState(1)
  const [active2, setActive2] = useState(1)

  const {
    register,
    handleSubmit,
    trigger,
    formState: { errors, isValid },
  } = useForm({
    // resolver: yupResolver(schema),
    mode: "all",
  })

  const [complexityValue, setComplexityValue] = useState([50])
  const [sophiscationValue, setSophiscationValue] = useState([50])
  const [timeFrameValue, setTimeFrameValue] = useState([50])
  const [rangeValues, setRangeValues] = useState([25, 75])

  const getData = file => {
    console.log(file)
  }

  const getRangeValues = value => {
    setRangeValues(value)
    console.log(rangeValues)
  }

  const getRangeValuesTimeFrame = value => {
    setTimeFrameValue(value)
    console.log(timeFrameValue)
  }
  const getRangeValuesComplexity = value => {
    setComplexityValue(value)
    console.log(complexityValue)
  }
  const getRangeValuesSophiscation = value => {
    setSophiscationValue(value)
    console.log(sophiscationValue)
  }

  const onSubmit = data => {
    console.log(data)
    getData()
    getRangeValuesTimeFrame()
    getRangeValuesComplexity()
    getRangeValues()
    getRangeValuesSophiscation()
    console.log(selectedList)
  }

  const images = {
    header: convertToBgImage(getImage(data.header)),

    branding: getImage(data.branding),
    laptop: getImage(data.laptop),
    product: getImage(data.product),
    web: getImage(data.web),
  }

  const [list, setList] = useState([
    {
      icon: images.web,
      title: "Web Development",
      selected: false,
    },
    {
      icon: images.product,
      title: "Product Photography",
      selected: false,
    },
    {
      icon: images.laptop,
      title: "Digital Marketing",
      selected: false,
    },
    {
      icon: images.branding,
      title: "Branding",
      selected: false,
    },
    {
      icon: images.product,
      title: "Web Development",
      selected: false,
    },
  ])

  // const [services, setServices] = useState([
  //   ...service.map(ser => {
  //     return { ...ser, selected: false }
  //   }),
  // ])

  const [selectedList, setSelectedList] = useState([])
  const [selectedIndex, setSelectedIndex] = useState()

  const checkService = index => {
    let serviceItems = [...list]
    let serviceItem = { ...serviceItems[index] }
    serviceItem.selected = !serviceItem.selected
    serviceItems[index] = serviceItem
    setList([...serviceItems])
  }

  const selectedListNames = () => {
    console.log("selected")
    let serviceItems = [...list]
    const selectedList = []
    serviceItems.map(item => {
      if (item.selected) {
        selectedList.push(item.title)
      }
      return null
    })
    setSelectedList(selectedList)
    setActive(active + 1)
  }

  // const validateService = () => {
  //   const serviceItems = [...list]

  //   serviceItems.map((item, index) => {
  //     if (item.selected) {
  //       selectedServices.push(item.title)
  //     }
  //     return null
  //   })

  //   return selectedServices
  // }

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <div className="container mx-auto px-10 ">
        <div className="flex items-center justify-between py-2">
          <div>
            <Link to="/">
              <StaticImage
                src="../images/brand/logo.png"
                alt="wyld global"
                className="w-32 cursor-pointer"
              />
            </Link>
          </div>
          <div
            className="flex gap-2 items-center cursor-pointer"
            onClick={() => {
              {
                navigate("/")
              }
            }}
          >
            <div className="text-gray-400">Close Project Planner</div>
            <div className="w-6">
              <XCircleIcon className="w-full text-red-500 font-extralight" />
            </div>
          </div>
        </div>
      </div>

      <div className="py-24 flex items-center ">
        <div className="container mx-auto px-10">
          <div className="flex gap-2">
            {Array.apply(null, { length: 5 }).map((value, index) => {
              return (
                <div key={index}>
                  <div
                    className={
                      index == active - 1
                        ? "pt-1 bg-black px-8 inline-block"
                        : "pt-1 bg-gray-300 px-8 inline-block"
                    }
                  ></div>
                </div>
              )
            })}
          </div>

          {active === 1 && (
            <div>
              <div className="mt-14 font-bold text-5xl">Start a Project</div>
              <div className="mt-8 font-semibold ">
                Thanks for your interest in working with us. Please complete the
                details below and we’ll get back to you within one business day.
              </div>

              <div className="mt-14 ">
                <div>What should we call you?</div>

                <input
                  type="text"
                  name="name"
                  placeholder="Enter your name here"
                  className="border rounded-full w-full px-14 py-4 mt-6"
                  {...register("name", {
                    required: true,
                    pattern: {
                      value: /^[a-z ,.'-]+$/i,
                      message: "You Can Only Use Letters",
                    },
                  })}
                />
                {errors.name ? (
                  <>
                    {errors.name.message ? (
                      <>
                        <div className="text-xs text-red-400 font-firs-light mt-1">
                          {errors.name.message}
                        </div>
                      </>
                    ) : (
                      <>
                        <div className="text-xs text-red-400 font-firs-light mt-1">
                          Name cannot be empty
                        </div>
                      </>
                    )}
                  </>
                ) : null}
              </div>

              <div className="mt-14 ">
                <div>What is the name of your company / organisation?</div>

                <input
                  {...register("organization", {
                    required: true,
                    pattern: {
                      value: /^[a-z ,.'-]+$/i,
                      message: "You Can Only Use Letters",
                    },
                  })}
                  type="text"
                  name="organization"
                  placeholder="Ex: Theewra worldwide"
                  className="border rounded-full w-full px-14 py-4 mt-6"
                />
                {errors.organization ? (
                  <>
                    {errors.organization.message ? (
                      <>
                        <div className="text-xs text-red-400 font-firs-light mt-1">
                          {errors.organization.message}
                        </div>
                      </>
                    ) : (
                      <>
                        <div className="text-xs text-red-400 font-firs-light mt-1">
                          Organization cannot be empty
                        </div>
                      </>
                    )}
                  </>
                ) : null}
              </div>

              <div className="mt-14 ">
                <div>How shall we contact you?</div>

                <div className="flex gap-4">
                  <input
                    {...register("email", {
                      required: true,
                      pattern: {
                        value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                        message: "Email address is not valid",
                      },
                    })}
                    type="text"
                    name="email"
                    placeholder="Email adress"
                    className="border rounded-full w-full px-14 py-4 mt-6"
                  />
                  {errors.email ? (
                    <>
                      {errors.email.message ? (
                        <>
                          <div className="text-xs text-red-400 font-firs-light mt-1">
                            {errors.email.message}
                          </div>
                        </>
                      ) : (
                        <>
                          <div className="text-xs text-red-400 font-firs-light mt-1">
                            Email cannot be empty
                          </div>
                        </>
                      )}
                    </>
                  ) : null}
                  <input
                    {...register("number", {
                      required: true,
                      pattern: {
                        value:
                          /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/i,
                        message: "Number is not valid",
                      },
                    })}
                    type="text"
                    name="number"
                    placeholder="Phone number"
                    className="border rounded-full w-full px-14 py-4 mt-6"
                  />
                  {errors.number ? (
                    <>
                      {errors.number.message ? (
                        <>
                          <div className="text-xs text-red-400 font-firs-light mt-1">
                            {errors.number.message}
                          </div>
                        </>
                      ) : (
                        <>
                          <div className="text-xs text-red-400 font-firs-light mt-1">
                            Number cannot be empty
                          </div>
                        </>
                      )}
                    </>
                  ) : null}
                </div>
              </div>
            </div>
          )}

          {active === 2 && (
            <div>
              <div className="mt-14 font-bold text-5xl">
                What can we help you with?
              </div>
              <div className="mt-8 font-semibold ">Select the service type</div>

              <div className="mt-8">
                <div className="flex gap-4">
                  {list.map((item, index) => {
                    return (
                      <div key={index}>
                        <div
                          onClick={() => {
                            // checkService(index)
                            setSelectedIndex(index)
                          }}
                          className={
                            selectedIndex === index
                              ? "px-10 py-24 border shadow-lg rounded-3xl cursor-pointer bg-black"
                              : "px-10 py-24 border shadow-lg rounded-3xl cursor-pointer "
                          }
                        >
                          <div className="flex items-center justify-center ">
                            <div className="w-1/2 border shadow-lg py-4 rounded-3xl px-4">
                              <GatsbyImage
                                image={item.icon}
                                className="w-full"
                              />
                            </div>
                          </div>
                          <div
                            className={
                              selectedIndex === index
                                ? "text-lg text-center text-white pt-10"
                                : "text-lg text-center pt-10"
                            }
                          >
                            {item.title}
                          </div>
                          {/* {item.selected ? ( */}
                          <div className="flex justify-center pt-10">
                            <CheckCircleIcon className="w-7 text-white" />
                          </div>
                          {/* ) : null} */}
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>
            </div>
          )}

          {active === 3 && (
            <div>
              <div className="mt-14 font-bold text-5xl">
                Tell us about the project
              </div>
              <div className="mt-8 font-semibold ">Web development project</div>

              <div className="mt-14 ">
                <div>What should we call you?</div>
                <textarea
                  placeholder="Requirments, intentions, target audiance,goals etc"
                  className="border rounded-3xl w-full px-14 py-4 mt-6"
                  rows={5}
                  name="requirement"
                  {...register("requirement", {
                    required: true,
                    pattern: {
                      value: /^[a-z ,.'-]+$/i,
                      message: "You Can Only Use Letters",
                    },
                  })}
                />
                {errors.requirement ? (
                  <>
                    {errors.requirement.message ? (
                      <>
                        <div className="text-xs text-red-400 font-firs-light mt-1">
                          {errors.requirement.message}
                        </div>
                      </>
                    ) : (
                      <>
                        <div className="text-xs text-red-400 font-firs-light mt-1">
                          requirement cannot be empty
                        </div>
                      </>
                    )}
                  </>
                ) : null}
              </div>
              {/* <div>
                <div className="mt-14">Attach any relevent documents</div>
                <div className="mt-8 w-full">
                  <section className="container">
                    <div
                      className="py-20 w-full border-2 border-dashed rounded-3xl"
                      {...getRootProps()}
                    >
                      <input {...getInputProps()} />
                      <div className="flex justify-center">
                        <div>
                          <div className="flex justify-center py-4">
                            <CloudUploadIcon className="w-24 text-gray-400 text-center" />
                          </div>

                          <div className="text-center text-xl text-gray-400 font-semibold">
                            Drag and Drop Files here
                          </div>
                          <div className="flex gap-3 justify-center">
                            <div className=" text-gray-400">or</div>
                            <div className="text-red-600 font-semibold  ">
                              Browse
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="grid gap-6 grid-cols-5 mt-8">
                      {myFiles.map((item, index) => {
                        return (
                          <div
                            key={index}
                            className="px-2  pt-2 border rounded-xl  relative"
                          >
                            <XCircleIcon
                              className="w-6 text-red-600 absolute -top-4 -right-5 cursor-pointer hover:scale-125 duration-300"
                              onClick={() => removeFile(index)}
                            />
                            <div className="">
                              <img
                                src={URL.createObjectURL(item)}
                                alt={item.name}
                                className="rounded-xl"
                              />
                            </div>

                            <div className="py-4 text-sm ">{item.name}</div>
                          </div>
                        )
                      })}
                    </div>
                  </section>
                </div>
              </div> */}
              <Uploader getData={getData} />
            </div>
          )}

          {active === 4 && (
            <div>
              <div className="mt-14 font-bold text-5xl">
                What is Your Budget?
              </div>
              <div className="mt-8 font-semibold ">
                A transparent budget will help us ensure expectations are met.
                Not sure? Ballparks are fine.
              </div>

              {active2 === 1 && (
                <div>
                  <div className="mt-20">
                    <div className="w-2/3">
                      <Labeled getRangeValues={getRangeValues} />
                    </div>
                  </div>
                  <div
                    className="mt-8 inline-block cursor-pointer "
                    onClick={() => setActive2(2)}
                  >
                    <Button title="I don't Know my Budget" />
                  </div>
                </div>
              )}

              {active2 === 2 && (
                <div>
                  <div className="mt-8 w-1/2">
                    <div className="mb-8 font-semibold">Time Frame</div>
                    <TimeFrame
                      getRangeValuesTimeFrame={getRangeValuesTimeFrame}
                    />
                  </div>
                  <div className="mt-8 w-1/2">
                    <div className="mb-8 font-semibold">Complexity</div>
                    <Complexity
                      getRangeValuesComplexity={getRangeValuesComplexity}
                    />
                  </div>
                  <div className="mt-8 w-1/2">
                    <div className="mb-8 font-semibold">Sophistication</div>
                    <Sophistication
                      getRangeValuesSophiscation={getRangeValuesSophiscation}
                    />
                  </div>
                  <div
                    className="mt-8 inline-block cursor-pointer "
                    onClick={() => setActive2(1)}
                  >
                    <Button title="I'd prefer to tell my Budget" />
                  </div>
                </div>
              )}
            </div>
          )}

          {active === 5 && (
            <div>
              <div className="mt-14 font-bold text-5xl">Lastly</div>
              <div className="mt-8 font-semibold ">Let's wrap this Up</div>

              <div className="mt-14 ">
                <div>What's your ideal timeframe?</div>

                <input
                  type="text"
                  name="timeFrame"
                  placeholder="Have a date in mind?"
                  className="border rounded-full w-full px-14 py-4 mt-6"
                  {...register("timeFrame", {
                    required: true,
                    pattern: {
                      value: /^[a-z ,.'-]+$/i,
                      message: "You Can Only Use Letters",
                    },
                  })}
                />
                {errors.timeFrame ? (
                  <>
                    {errors.timeFrame.message ? (
                      <>
                        <div className="text-xs text-red-400 font-firs-light mt-1">
                          {errors.timeFrame.message}
                        </div>
                      </>
                    ) : (
                      <>
                        <div className="text-xs text-red-400 font-firs-light mt-1">
                          This field cannot be empty
                        </div>
                      </>
                    )}
                  </>
                ) : null}
              </div>
              <div className="mt-14 ">
                <div>How did you hear about us?</div>

                <input
                  type="text"
                  name="hear"
                  placeholder="Ex: Word of mouth"
                  className="border rounded-full w-full px-14 py-4 mt-6"
                  {...register("hear", {
                    required: true,
                    pattern: {
                      value: /^[a-z ,.'-]+$/i,
                      message: "You Can Only Use Letters",
                    },
                  })}
                />
                {errors.hear ? (
                  <>
                    {errors.hear.message ? (
                      <>
                        <div className="text-xs text-red-400 font-firs-light mt-1">
                          {errors.hear.message}
                        </div>
                      </>
                    ) : (
                      <>
                        <div className="text-xs text-red-400 font-firs-light mt-1">
                          This field cannot be empty
                        </div>
                      </>
                    )}
                  </>
                ) : null}
              </div>
            </div>
          )}
          <div className="flex gap-4 mt-10">
            <button
              onClick={() => {
                setActive(active - 1)
              }}
            >
              Back
            </button>

            <button
              type={active == 5 ? "submit" : "button"}
              disabled={!isValid}
              onClick={() => {
                if (active === 1) {
                  setActive(active + 1)
                } else if (active === 2) {
                  selectedListNames()
                } else if (active === 3) {
                  selectedListNames()
                } else if (active === 4) {
                  setActive(active + 1)
                }
              }}
              className={
                isValid
                  ? "py-1 px-6 border border-black rounded-full bg-black text-white group cursor-pointer"
                  : "py-1 px-6 border border-black/10 rounded-full bg-black/50 text-white group cursor-not-allowed cursor-"
              }
            >
              <div className="flex items-center">
                {active === 5 ? (
                  <div className="">Submit</div>
                ) : (
                  <div className="">Next</div>
                )}

                <div className="">
                  <ArrowNarrowRightIcon className="w-5 -ml-8 group-hover:ml-2 duration-200 text-transparent group-hover:text-white" />
                </div>
              </div>
            </button>

            {/* <div
              className="inline-block mt-14 cursor-pointer "
              onClick={() => {
                active === 1 ? setActive(active) : setActive(active - 1)
              }}
            >
              <Button title="Back" />
            </div>
            <div
              className={"inline-block mt-14 cursor-pointer "}
              onClick={() => {
                if (active === 1) {
                  if (isValid) {
                    setActive(active + 1)
                  } else setActive(active)
                } else if (active === 2) {
                  if (isValid) {
                    setActive(active + 1)
                  } else setActive(active)
                } else if (active === 3) {
                  if (isValid) {
                    setActive(active + 1)
                  } else setActive(active)
                }
              }}
            >
              <Button title="Next" />
            </div> */}
          </div>
        </div>
        {/* <BackgroundImage {...images.header} className="py-64"></BackgroundImage> */}
        {/* <div class="h-96 w-96 absolute top-0 bg-gradient-to-b from-pink-500 via-purple-500 to-white opacity-40  "></div> */}
      </div>
    </form>
  )
}
export const query = graphql`
  query FormImages {
    interstellar: file(relativePath: { eq: "homepage/interstellar.jpg" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    header: file(relativePath: { eq: "homepage/header.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    branding: file(relativePath: { eq: "contact/branding.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    laptop: file(relativePath: { eq: "contact/laptop.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    product: file(relativePath: { eq: "contact/product.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    web: file(relativePath: { eq: "contact/web.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
  }
`

export default Form
