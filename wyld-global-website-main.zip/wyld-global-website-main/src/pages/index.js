import * as React from "react"
import { Link } from "gatsby"
import { StaticImage } from "gatsby-plugin-image"
import { graphql } from "gatsby"
import { getImage, GatsbyImage } from "gatsby-plugin-image"

import { convertToBgImage } from "gbimage-bridge"
import BackgroundImage from "gatsby-background-image"

import Layout from "../components/layout"
import Seo from "../components/seo"
import Button from "../components/elements/button"
import HomepageSlider from "../components/sliders/homepage-slider"
import HomepageSlider2 from "../components/sliders/homepage-slider2"
import Marquee from "react-fast-marquee"
import { useState, useEffect } from "react"
import { PlayIcon } from "@heroicons/react/outline"
import { PauseIcon } from "@heroicons/react/outline"
import $ from "jquery"

const Home = ({ data }) => {
  const [speed, setSpeed] = useState(0)
  const [play, setPlay] = useState(true)

  // useEffect(() => {
  //   $(".wrapper").on({
  //     mouseenter: function () {
  //       setSpeed(0)
  //     },
  //     mouseleave: function () {
  //       setSpeed(100)
  //     },
  //   })
  // })
  const images = {
    interstellar: convertToBgImage(getImage(data.interstellar)),
    interstellar1: getImage(data.interstellar),
    header: getImage(data.header),

    //marquee1 images

    mars1: getImage(data.mars1),
    mars2: getImage(data.mars2),
    mars3: getImage(data.mars3),
    mars4: getImage(data.mars4),
    mars5: getImage(data.mars5),
    mars6: getImage(data.mars6),
    mars7: getImage(data.mars7),
    mars8: getImage(data.mars8),
    mars9: getImage(data.mars9),
    mars10: getImage(data.mars10),
    mars11: getImage(data.mars11),
    mars12: getImage(data.mars12),

    //slider images

    pluto1: convertToBgImage(getImage(data.pluto1)),
    pluto2: convertToBgImage(getImage(data.pluto2)),
    pluto3: convertToBgImage(getImage(data.pluto3)),
    pluto4: convertToBgImage(getImage(data.pluto4)),
    pluto5: convertToBgImage(getImage(data.pluto5)),
    pluto6: convertToBgImage(getImage(data.pluto6)),
    pluto7: convertToBgImage(getImage(data.pluto7)),
    pluto8: convertToBgImage(getImage(data.pluto8)),

    //icons

    crown: getImage(data.crown),
    laptop: getImage(data.laptop),
    megaphone: getImage(data.megaphone),
    strategy: getImage(data.strategy),
  }

  const slider = [
    {
      image: images.pluto1,
      topic: "Drama",
      desc: "Client/Wichi",
    },
    {
      image: images.pluto2,
      topic: "Lorem",
      desc: "Client/Joseph",
    },
    {
      image: images.pluto3,
      topic: "Fiction",
      desc: "Client/Brand",
    },
    {
      image: images.pluto4,
      topic: "Drama",
      desc: "Client/Venuka",
    },
    {
      image: images.pluto5,
      topic: "Movie",
      desc: "Client/Joe",
    },
  ]

  const marque1 = [
    {
      image: images.mars1,
    },
    {
      image: images.mars2,
    },
    {
      image: images.mars3,
    },
    {
      image: images.mars4,
    },
    {
      image: images.mars5,
    },
    {
      image: images.mars6,
    },
  ]

  const marque2 = [
    {
      image: images.mars7,
    },
    {
      image: images.mars8,
    },
    {
      image: images.mars9,
    },
    {
      image: images.mars10,
    },
    {
      image: images.mars11,
    },
    {
      image: images.mars12,
    },
  ]

  const featured = [
    {
      image: images.mars7,

      title: "Rawwath dasin",
      author: "Yohani Perera",
    },
    {
      image: images.mars8,

      title: "Tropical beverages",
      author: "Wichi Coconut",
    },
    {
      image: images.mars9,

      title: "Band Campaign",
      author: "Nations Trust",
    },
    {
      image: images.mars10,
      title: "Indian Ocean",
      author: "Apple TV",
    },
    {
      image: images.mars11,
      title: "Swan Song",
      author: "Apple TV",
    },
    {
      image: images.mars12,
      title: "Metalegend",
      author: "Yohani Perera",
    },
    {
      image: images.mars3,
      title: "Wyld Global",
      author: "Supun Perera",
    },
    {
      image: images.mars2,
      title: "Tech Pacific",
      author: "Apple TV",
    },
  ]

  const wyldBussiness = [
    {
      icon: images.strategy,
      title: "Strategy",
      desc: "Our own 'The Unsual®' way as a strategy platform that deliver you sales overnight and build your brand over time.",
    },
    {
      icon: images.crown,
      title: "Branding",
      desc: "Tried and tested multidisciplinary creative brand thinking to accelerate and future-proof your brand.",
    },
    {
      icon: images.laptop,
      title: "Web",
      desc: "Create new growth by elevating the digital products & experiences of your brand—with connected ideas, technology, and creative talent.",
    },
    {
      icon: images.megaphone,
      title: "Social",
      desc: "Unique brand interactions online that spark imaginations and create conversations.",
    },
  ]

  return (
    <Layout>
      <Seo title="Home" />
      <div className="container mx-auto px-10  ">
        <div className="flex h-screen items-center ">
          <div className="text-center lg:text-left">
            <div className="text-5xl sm:text-6xl md:text-7xl 2xl:text-8xl font-extrabold">
              A Global Creative Network
            </div>
            <div className="mt-4 text-xl ">
              We build wild relationships with brands and their customers.
            </div>
          </div>
          <div>
            <GatsbyImage
              image={images.header}
              className="w-full lg:block hidden"
            />
          </div>
        </div>
      </div>

      <section>
        <div className="  pb-24  ">
          <div className="text-xl font-semibold mb-14 container mx-auto px-10 ">
            Featured Projects
          </div>
          <div>
            <HomepageSlider slider_array={slider} />
          </div>
          <div className="mt-3 md:mt-5"></div>
          <div className="">
            <Marquee
              className="wrapper"
              speed={70}
              gradient={false}
              play={play}
              pauseOnHover={false}
            >
              {marque1.map((item, index) => {
                return (
                  <div key={index}>
                    <div className="relative w-60 md:w-72 lg:w-80 xl:w-96 mr-3 md:mr-5 ">
                      <GatsbyImage
                        image={item.image}
                        className="w-full rounded-3xl "
                      />
                      <div className="bg-black/75  w-full h-full  absolute top-0 rounded-3xl opacity-0 hover:opacity-100 duration-200  ">
                        <div className=" flex items-center justify-center h-full">
                          <Button title="Learn More" filledWhite />
                        </div>
                      </div>
                    </div>
                  </div>
                )
              })}
            </Marquee>
          </div>

          <div className="wrapper mt-3 md:mt-5">
            <Marquee
              speed={30}
              gradient={false}
              play={play}
              pauseOnHover={false}
            >
              {marque2.map((item, index) => {
                return (
                  <div key={index}>
                    <div className="relative w-60 md:w-72 lg:w-80 xl:w-96 mr-3 md:mr-5">
                      <GatsbyImage
                        image={item.image}
                        className="w-full rounded-3xl "
                      />
                      <div className="bg-black/75  w-full h-full  absolute top-0 rounded-3xl opacity-0 hover:opacity-100 duration-200  ">
                        <div className=" flex items-center justify-center h-full">
                          <Button title="Learn More" filledWhite />
                        </div>
                      </div>
                    </div>
                  </div>
                )
              })}
            </Marquee>
          </div>

          <div>
            <div className="flex items-center md:justify-center mt-14">
              <Button title="All Projects" />
              <div className="absolute right-0 px-8 md:px-32 flex items-center ">
                <button
                  id="playbtn "
                  onClick={() => {
                    setPlay(!play)
                  }}
                >
                  {play ? (
                    <PauseIcon className="w-12 stroke-1 " />
                  ) : (
                    <PlayIcon className="w-12 stroke-1 " />
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section>
        <div className="container mx-auto px-10 pb-24  ">
          <div className="text-xl font-semibold mb-14">
            WYLD Business Essentials
          </div>
          <div>
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
              {wyldBussiness.map((item, index) => {
                return (
                  <div key={index}>
                    <div className="flex items-center h-full px-5 py-20 border rounded-3xl">
                      <div>
                        <div className="w-1/4 bg-secondary-dark rounded-full px-5 py-5">
                          <GatsbyImage image={item.icon} className="w-full" />
                        </div>

                        <div className="text-lg font-semibold pt-5">
                          {item.title}
                        </div>

                        <div className="h-32 pt-4">{item.desc}</div>
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      </section>

      <section>
        <div className="container mx-auto px-10 pb-24  ">
          <div className="text-xl font-semibold mb-14">Featured Projects</div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 ">
            {featured.map((item, index) => {
              return (
                <div key={index}>
                  <div className=" border rounded-3xl ">
                    <div>
                      <GatsbyImage
                        image={item.image}
                        className="w-full rounded-3xl "
                      />
                    </div>
                    <div className="py-4 px-5">
                      <div className=" font-semibold text-lg">{item.title}</div>
                      <div className=" ">{item.author}</div>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </section>
    </Layout>
  )
}
export const query = graphql`
  query HomepageImages {
    interstellar: file(relativePath: { eq: "homepage/interstellar.jpg" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    header: file(relativePath: { eq: "homepage/header.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    mars1: file(relativePath: { eq: "homepage/mars1.webp" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    mars2: file(relativePath: { eq: "homepage/mars2.webp" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    mars3: file(relativePath: { eq: "homepage/mars3.webp" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    mars4: file(relativePath: { eq: "homepage/mars4.webp" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    mars5: file(relativePath: { eq: "homepage/mars5.webp" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    mars6: file(relativePath: { eq: "homepage/mars6.webp" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    mars7: file(relativePath: { eq: "homepage/mars7.webp" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    mars8: file(relativePath: { eq: "homepage/mars8.webp" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    mars9: file(relativePath: { eq: "homepage/mars9.webp" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    mars10: file(relativePath: { eq: "homepage/mars10.webp" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    mars11: file(relativePath: { eq: "homepage/mars11.webp" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    mars12: file(relativePath: { eq: "homepage/mars12.webp" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    pluto1: file(relativePath: { eq: "homepage/pluto1.webp" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    pluto2: file(relativePath: { eq: "homepage/pluto2.webp" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    pluto3: file(relativePath: { eq: "homepage/pluto3.webp" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    pluto4: file(relativePath: { eq: "homepage/pluto4.webp" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    pluto5: file(relativePath: { eq: "homepage/pluto5.webp" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    pluto6: file(relativePath: { eq: "homepage/pluto6.webp" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    pluto7: file(relativePath: { eq: "homepage/pluto7.webp" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    pluto8: file(relativePath: { eq: "homepage/pluto8.webp" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    crown: file(relativePath: { eq: "homepage/icons/crown.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    laptop: file(relativePath: { eq: "homepage/icons/laptop.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    megaphone: file(relativePath: { eq: "homepage/icons/megaphone.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    strategy: file(relativePath: { eq: "homepage/icons/strategy.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
  }
`

export default Home
