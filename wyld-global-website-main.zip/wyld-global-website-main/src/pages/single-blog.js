import React from "react"
import Layout from "../components/layout"
import { Link } from "gatsby"
import { StaticImage } from "gatsby-plugin-image"
import { graphql } from "gatsby"
import { getImage, GatsbyImage } from "gatsby-plugin-image"

import { convertToBgImage } from "gbimage-bridge"
import BackgroundImage from "gatsby-background-image"
import Seo from "../components/seo"
import Button from "../components/elements/button"
import HomepageSlider from "../components/sliders/homepage-slider"
import HomepageSlider2 from "../components/sliders/homepage-slider2"
import Marquee from "react-fast-marquee"
import { useState, useEffect } from "react"
import { LinkIcon } from "@heroicons/react/solid"
import {} from "@heroicons/react/outline"
import $ from "jquery"

const Blog = ({ data }) => {
  const images = {
    //marquee1 images

    mars1: getImage(data.mars1),
    mars2: getImage(data.mars2),
    mars3: getImage(data.mars3),
    mars4: getImage(data.mars4),
    mars5: getImage(data.mars5),
    mars6: getImage(data.mars6),
    mars7: getImage(data.mars7),
    mars8: getImage(data.mars8),
    mars9: getImage(data.mars9),
    mars10: getImage(data.mars10),
    mars11: getImage(data.mars11),
    mars12: getImage(data.mars12),

    //slider images

    pluto1: convertToBgImage(getImage(data.pluto1)),
    pluto2: convertToBgImage(getImage(data.pluto2)),
    pluto3: convertToBgImage(getImage(data.pluto3)),
    pluto4: convertToBgImage(getImage(data.pluto4)),
    pluto5: convertToBgImage(getImage(data.pluto5)),
    pluto6: convertToBgImage(getImage(data.pluto6)),
    pluto7: convertToBgImage(getImage(data.pluto7)),
    pluto8: convertToBgImage(getImage(data.pluto8)),

    //social icons

    attach: getImage(data.attach),
    email: getImage(data.email),
    facebook: getImage(data.facebook),
    twitter: getImage(data.twitter),

    //blog page hoem images

    tree: getImage(data.tree),
    boat: getImage(data.boat),
  }

  const socialIcons = [
    {
      icon: images.attach,
    },
    {
      icon: images.facebook,
    },
    {
      icon: images.twitter,
    },
    {
      icon: images.email,
    },
  ]

  const news = [
    {
      category: "Category Name",
      title: "10 photography tips up your product photography",
      author: "By John Doe",
      date: "Novemvber 24 2022",
      image: images.pluto1,
    },
    {
      category: "Category Name",
      title: "Shoot that you’ll never ever forget the area that you covered",
      author: "By John Doe",
      date: "Novemvber 24 2022",
      image: images.pluto2,
    },
    {
      category: "Category Name",
      title: "10 photography tips up your product photography",
      author: "By John Doe",
      date: "Novemvber 24 2022",
      image: images.pluto3,
    },
    {
      category: "Category Name",
      title: "10 Crucial Makeup Photography Tips",
      author: "By John Doe",
      date: "Novemvber 24 2022",
      image: images.pluto4,
    },
    {
      category: "Category Name",
      title: "Shoot that you’ll never ever forget",
      author: "By John Doe",
      date: "Novemvber 24 2022",
      image: images.pluto5,
    },
    {
      category: "Category Name",
      title: "Shoot that you’ll never ever forget",
      author: "By John Doe",
      date: "Novemvber 24 2022",
      image: images.pluto7,
    },
  ]
  return (
    <Layout>
      <section>
        <div className="container mx-auto px-10   ">
          <div className="flex  items-center justify-center h-screen  ">
            <div>
              <div className="mb-10 text-center"> Category | May 4,2022</div>
              <div className="text-4xl sm:text-5xl font-bold  text-center  ">
                10 photography tips up your
                <div>product photography</div>
              </div>
              <div className="mt-10 text-center max-w-xl mx-auto">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam
              </div>

              <div className="flex gap-10 items-center justify-center mt-14">
                {socialIcons.map((item, index) => {
                  return (
                    <div key={index}>
                      <div className="flex justify-center">
                        <GatsbyImage image={item.icon} className="w-8" />
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section>
        <div className="pb-24  ">
          <div>
            <GatsbyImage image={images.tree} />
          </div>
          <div className="container mx-auto px-10   ">
            <div className="mt-5 text-center">
              Description of the image / paragraph written about the image or
              video
            </div>
            <div className="mt-14  max-w-4xl mx-auto text-justify">
              Written Content - Lorem ipsum dolor sit amet, consectetur
              adipiscing elit, sed do eiusmod tempor incididunt ut labore et
              dolore magna aliqua. Tellus in hac habitasse platea dictumst. Sed
              turpis tincidunt id aliquet risus feugiat. Ipsum dolor sit amet
              consectetur. Nibh nisl condimentum id venenatis a condimentum. Eu
              lobortis elementum nibh tellus molestie nunc non blandit. Congue
              quisque egestas diam in arcu cursus euismod. Vivamus at augue eget
              arcu dictum varius duis at consectetur. Malesuada fames ac turpis
              egestas integer eget aliquet nibh praesent. Faucibus pulvinar
              elementum integer enim neque. Feugiat vivamus at augue eget.
              Egestas purus viverra accumsan in nisl nisi scelerisque eu
              ultrices. Dignissim cras tincidunt lobortis feugiat vivamus at
              augue. Elit sed vulputate mi sit amet. Dui ut ornare lectus sit
              amet. Vulputate ut pharetra sit amet. Risus pretium quam vulputate
              dignissim suspendisse in. Nisl purus in mollis nunc. Id velit ut
              tortor pretium viverra suspendisse potenti. Elementum pulvinar
              etiam non quam lacus suspendisse faucibus interdum posuere. Morbi
              tempus iaculis urna id volutpat. Sed risus ultricies tristique
              nulla aliquet enim tortor at. Lectus nulla at volutpat diam ut
              venenatis. Neque convallis a cras semper auctor. Aliquam
              vestibulum morbi blandit cursus risus at ultrices mi tempus. Donec
              et odio pellentesque diam volutpat. Vivamus at augue eget arcu
              dictum varius duis. Egestas congue quisque egestas diam in arcu
              cursus. Urna et pharetra pharetra massa massa ultricies mi quis.
              Eu sem integer vitae justo eget magna fermentum. Interdum velit
              laoreet id donec ultrices tincidunt arcu. Vel quam elementum
              pulvinar etiam non quam lacus.
            </div>
            <div className="mt-14 max-w-4xl mx-auto text-justify">
              Written Content - Lorem ipsum dolor sit amet, consectetur
              adipiscing elit, sed do eiusmod tempor incididunt ut labore et
              dolore magna aliqua. Tellus in hac habitasse platea dictumst. Sed
              turpis tincidunt id aliquet risus feugiat. Ipsum dolor sit amet
              consectetur. Nibh nisl condimentum id venenatis a condimentum. Eu
              lobortis elementum nibh tellus molestie nunc non blandit. Congue
              quisque egestas diam in arcu cursus euismod. Vivamus at augue eget
              arcu dictum varius duis at consectetur. Malesuada fames ac turpis
              egestas integer eget aliquet nibh praesent. Faucibus pulvinar
              elementum integer enim neque. Feugiat vivamus at augue eget.
              Egestas purus viverra accumsan in nisl nisi scelerisque eu
              ultrices. Dignissim cras tincidunt lobortis feugiat vivamus at
              augue. Elit sed vulputate mi sit amet. Dui ut ornare lectus sit
              amet. Vulputate ut pharetra sit amet. Risus pretium quam vulputate
              dignissim suspendisse in. Nisl purus in mollis nunc. Id velit ut
              tortor pretium viverra suspendisse potenti. Elementum pulvinar
              etiam non quam lacus suspendisse faucibus interdum posuere. Morbi
              tempus iaculis urna id volutpat. Sed risus ultricies tristique
              nulla aliquet enim tortor at. Lectus nulla at volutpat diam ut
              venenatis. Neque convallis a cras semper auctor. Aliquam
              vestibulum morbi blandit cursus risus at ultrices mi tempus. Donec
              et odio pellentesque diam volutpat. Vivamus at augue eget arcu
              dictum varius duis. Egestas congue quisque egestas diam in arcu
              cursus. Urna et pharetra pharetra massa massa ultricies mi quis.
              Eu sem integer vitae justo eget magna fermentum. Interdum velit
              laoreet id donec ultrices tincidunt arcu. Vel quam elementum
              pulvinar etiam non quam lacus.
            </div>
          </div>
        </div>
      </section>

      <section>
        <div className="pb-24  ">
          <div>
            <GatsbyImage image={images.boat} />
          </div>
          <div className="container mx-auto px-10 ">
            <div className="mt-5 text-center">
              Description of the image / paragraph written about the image or
              video
            </div>
            <div className="mt-14  max-w-4xl mx-auto text-justify">
              Written Content - Lorem ipsum dolor sit amet, consectetur
              adipiscing elit, sed do eiusmod tempor incididunt ut labore et
              dolore magna aliqua. Tellus in hac habitasse platea dictumst. Sed
              turpis tincidunt id aliquet risus feugiat. Ipsum dolor sit amet
              consectetur. Nibh nisl condimentum id venenatis a condimentum. Eu
              lobortis elementum nibh tellus molestie nunc non blandit. Congue
              quisque egestas diam in arcu cursus euismod. Vivamus at augue eget
              arcu dictum varius duis at consectetur. Malesuada fames ac turpis
              egestas integer eget aliquet nibh praesent. Faucibus pulvinar
              elementum integer enim neque. Feugiat vivamus at augue eget.
              Egestas purus viverra accumsan in nisl nisi scelerisque eu
              ultrices. Dignissim cras tincidunt lobortis feugiat vivamus at
              augue. Elit sed vulputate mi sit amet. Dui ut ornare lectus sit
              amet. Vulputate ut pharetra sit amet. Risus pretium quam vulputate
              dignissim suspendisse in. Nisl purus in mollis nunc. Id velit ut
              tortor pretium viverra suspendisse potenti. Elementum pulvinar
              etiam non quam lacus suspendisse faucibus interdum posuere. Morbi
              tempus iaculis urna id volutpat. Sed risus ultricies tristique
              nulla aliquet enim tortor at. Lectus nulla at volutpat diam ut
              venenatis. Neque convallis a cras semper auctor. Aliquam
              vestibulum morbi blandit cursus risus at ultrices mi tempus. Donec
              et odio pellentesque diam volutpat. Vivamus at augue eget arcu
              dictum varius duis. Egestas congue quisque egestas diam in arcu
              cursus. Urna et pharetra pharetra massa massa ultricies mi quis.
              Eu sem integer vitae justo eget magna fermentum. Interdum velit
              laoreet id donec ultrices tincidunt arcu. Vel quam elementum
              pulvinar etiam non quam lacus.
            </div>

            <div className="mt-14 text-center text-3xl font-semibold">
              "Quote: Being featured as App of the Day has been tremendous for
              us, not just in generating downloads the day of, but also in
              becoming a badge of approval that continues to add credibility in
              conversations with potential customers, investors, and employees
              for several months afterward."
            </div>
            <div className="mt-5 text-center">
              Description of the image / paragraph written about the image or
              video
            </div>
            <div className="max-w-4xl mx-auto text-justify">
              <div className="mt-14  ">
                Written Content - Lorem ipsum dolor sit amet, consectetur
                adipiscing elit, sed do eiusmod tempor incididunt ut labore et
                dolore magna aliqua. Tellus in hac habitasse platea dictumst.
                Sed turpis tincidunt id aliquet risus feugiat. Ipsum dolor sit
                amet consectetur. Nibh nisl condimentum id venenatis a
                condimentum. Eu lobortis elementum nibh tellus molestie nunc non
                blandit. Congue quisque egestas diam in arcu cursus euismod.
                Vivamus at augue eget arcu dictum varius duis at consectetur.
                Malesuada fames ac turpis egestas integer eget aliquet nibh
                praesent. Faucibus pulvinar elementum integer enim neque.
                Feugiat vivamus at augue eget. Egestas purus viverra accumsan in
                nisl nisi scelerisque eu ultrices. Dignissim cras tincidunt
                lobortis feugiat vivamus at augue. Elit sed vulputate mi sit
                amet. Dui ut ornare lectus sit amet. Vulputate ut pharetra sit
                amet. Risus pretium quam vulputate dignissim suspendisse in.
                Nisl purus in mollis nunc. Id velit ut tortor pretium viverra
                suspendisse potenti. Elementum pulvinar etiam non quam lacus
                suspendisse faucibus interdum posuere. Morbi tempus iaculis urna
                id volutpat. Sed risus ultricies tristique nulla aliquet enim
                tortor at. Lectus nulla at volutpat diam ut venenatis. Neque
                convallis a cras semper auctor. Aliquam vestibulum morbi blandit
                cursus risus at ultrices mi tempus. Donec et odio pellentesque
                diam volutpat. Vivamus at augue eget arcu dictum varius duis.
                Egestas congue quisque egestas diam in arcu cursus. Urna et
                pharetra pharetra massa massa ultricies mi quis. Eu sem integer
                vitae justo eget magna fermentum. Interdum velit laoreet id
                donec ultrices tincidunt arcu. Vel quam elementum pulvinar etiam
                non quam lacus.
              </div>

              <div className="mt-14 font-semibold">Share Article</div>
              <div className="flex gap-4 items-center mt-8">
                {socialIcons.map((item, index) => {
                  return (
                    <div key={index}>
                      <div className="flex justify-center">
                        <GatsbyImage image={item.icon} className="w-6" />
                      </div>
                    </div>
                  )
                })}
              </div>
              <div className="my-14">
                <div className="bg-gray-300 w-full h-[2.5px]"></div>
              </div>
              <div>
                <div className="font-semibold">press Contents</div>
                <div className="mt-8">
                  <div>news@xyc.com</div>
                  <div>Jane Doe</div>
                  <div> +91 1223 5678</div>
                </div>
              </div>

              <div className="my-14">
                <div className="bg-gray-300 w-full h-[2.5px]"></div>
              </div>

              <div className="mt-14 font-semibold">Latest News</div>
            </div>
          </div>

          <div className="container mx-auto px-10 ">
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-5 mt-14 ">
              {news.map((item, index) => {
                return (
                  <div key={index}>
                    <div className=" shadow-lg shadow-black/25 rounded-3xl ">
                      <div>
                        {/* <GatsbyImage
                          image={item.image}
                          className="w-full rounded-3xl "
                        /> */}
                        <BackgroundImage
                          {...item.image}
                          className="py-44 overflow-hidden rounded-3xl"
                        ></BackgroundImage>
                      </div>
                      <div className="px-5 pb-6">
                        <div className=" pt-5 text-md text-black/60">
                          {item.category}
                        </div>
                        <div className=" text-xl font-semibold pt-3 ">
                          {item.title}
                        </div>
                        <div className="bg-gray-300 w-full h-[2.5px] my-5"></div>
                        <div className="flex justify-between text-black/60">
                          <div>{item.author}</div>
                          <div>{item.date}</div>
                        </div>
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      </section>
    </Layout>
  )
}

export const query = graphql`
  query BlogpageImages {
    interstellar: file(relativePath: { eq: "homepage/interstellar.jpg" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    header: file(relativePath: { eq: "homepage/header.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    mars1: file(relativePath: { eq: "homepage/mars1.webp" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    mars2: file(relativePath: { eq: "homepage/mars2.webp" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    mars3: file(relativePath: { eq: "homepage/mars3.webp" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    mars4: file(relativePath: { eq: "homepage/mars4.webp" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    mars5: file(relativePath: { eq: "homepage/mars5.webp" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    mars6: file(relativePath: { eq: "homepage/mars6.webp" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    mars7: file(relativePath: { eq: "homepage/mars7.webp" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    mars8: file(relativePath: { eq: "homepage/mars8.webp" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    mars9: file(relativePath: { eq: "homepage/mars9.webp" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    mars10: file(relativePath: { eq: "homepage/mars10.webp" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    mars11: file(relativePath: { eq: "homepage/mars11.webp" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    mars12: file(relativePath: { eq: "homepage/mars12.webp" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    pluto1: file(relativePath: { eq: "homepage/pluto1.webp" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    pluto2: file(relativePath: { eq: "homepage/pluto2.webp" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    pluto3: file(relativePath: { eq: "homepage/pluto3.webp" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    pluto4: file(relativePath: { eq: "homepage/pluto4.webp" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    pluto5: file(relativePath: { eq: "homepage/pluto5.webp" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    pluto6: file(relativePath: { eq: "homepage/pluto6.webp" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    pluto7: file(relativePath: { eq: "homepage/pluto7.webp" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    pluto8: file(relativePath: { eq: "homepage/pluto8.webp" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    attach: file(relativePath: { eq: "blog/attach.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    email: file(relativePath: { eq: "blog/email.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    facebook: file(relativePath: { eq: "blog/facebook.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    twitter: file(relativePath: { eq: "blog/twitter.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    tree: file(relativePath: { eq: "blog/tree.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
    boat: file(relativePath: { eq: "blog/boat.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
  }
`

export default Blog
