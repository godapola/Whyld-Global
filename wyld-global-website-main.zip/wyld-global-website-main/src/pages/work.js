import * as React from "react"
import { Link } from "gatsby"
import { StaticImage } from "gatsby-plugin-image"
import { graphql } from "gatsby"
import { getImage, GatsbyImage } from "gatsby-plugin-image"

import { convertToBgImage } from "gbimage-bridge"
import BackgroundImage from "gatsby-background-image"

import Layout from "../components/layout"
import Seo from "../components/seo"
import Button from "../components/elements/button"

const Work = ({ data }) => {
  const images = {
    header: convertToBgImage(getImage(data.header)),
    workimage1: getImage(data.workimage1),
    workimage2: getImage(data.workimage2),
    workimage3: getImage(data.workimage3),
    workimage4: getImage(data.workimage4),
    workimage5: getImage(data.workimage5),
    workimage6: getImage(data.workimage6),
    workimage7: getImage(data.workimage7),
    workimage8: getImage(data.workimage8),
  }

  const workpost = [
    {
      image: images.workimage1,
      title: "Rawwath dasin",
      name: "Yohani Diloka",
    },
    {
      image: images.workimage2,
      title: "Tropical beverages",
      name: "Wichy coconut",
    },
    {
      image: images.workimage3,
      title: "band Campain",
      name: "Nations Trust",
    },
    {
      image: images.workimage4,
      title: "prehistoric planet",
      name: "apple tv",
    },
    {
      image: images.workimage5,
      title: "Swan song",
      name: "Apple tv",
    },
    {
      image: images.workimage6,
      title: "Gem Photoshoot",
      name: "Punsiri gems",
    },
    {
      image: images.workimage7,
      title: "Shannara Chronicals",
      name: "ABC television",
    },
    {
      image: images.workimage8,
      title: "Discovery of Witches",
      name: "Sky orginal",
    },
  ]

  return (
    <Layout>
      <Seo title="Work" />

      <section>
        <BackgroundImage {...images.header}>
          <div className="container mx-auto px-10  pb-8">
            <div className="flex h-screen items-center ">
              <div>
                <div className="text-5xl sm:text-7xl md:text-8xl font-bold">
                  #minimalism
                </div>

                <div className="mt-4 text-xl font-bold">#Showreel</div>
              </div>
              <div></div>
            </div>
          </div>
        </BackgroundImage>
      </section>

      <section>
        <div className="container mx-auto px-10 py-24">
          <div className="text-3xl	font-bold"> Projects </div>

          <div class="flex flex-col overflow-x-auto scrollbar-hide xl:flex-row justify-between text-center  mt-12  mb-16  ">
            <div class="flex-none   bg-black	 text-white	  border  py-3 px-11  mr-2  rounded-3xl">
              all categories
            </div>
            <div class="flex-none  bg-dark-gray		 text-white	  border  py-3 px-11  mx-2  rounded-3xl">
              Photoshoot
            </div>
            <div class="flex-none  bg-dark-gray		 text-white	  border  py-3 px-11  mx-2  rounded-3xl">
              Music production
            </div>
            <div class="flex-none  bg-dark-gray		 text-white	  border  py-3 px-11  mx-2  rounded-3xl">
              Brand Identity
            </div>
            <div class="flex-none  bg-dark-gray		 text-white	  border  py-3 px-11  mx-2  rounded-3xl">
              Television Series
            </div>
            <div class="flex-none  bg-dark-gray		 text-white	  border  py-3 px-11  mx-2  rounded-3xl">
              category 06
            </div>
            <div class="flex-none  bg-dark-gray		 text-white	  border  py-3 px-11  mx-2  rounded-3xl">
              category 07
            </div>
            <div class="flex-none  bg-dark-gray		 text-white	  border  py-3 px-11  mx-2  rounded-3xl">
              category 07
            </div>
            <div class="flex-none  bg-dark-gray		 text-white	  border  py-3 px-11  mx-2  rounded-3xl">
              category 07
            </div>
          </div>

          <div class="grid md:grid-cols-2  lg:grid-cols-3  xl:grid-cols-4 gap-6 gap-x-6  gap-y-16">
            {workpost.map((workrow, index) => {
              return (
                <div className="bg-light-gray/75 pb-3 rounded-3xl	">
                  <GatsbyImage
                    image={workrow.image}
                    className="w-full rounded-3xl"
                  />

                  <div className="text-base	font-bold px-6	pt-4">
                    {workrow.title}
                  </div>
                  <div className="text-base	 font-normal	px-6	">
                    {" "}
                    {workrow.name}{" "}
                  </div>
                </div>
              )
            })}
          </div>

          <div className="grid justify-items-center pt-10">
            <div>
              <Button title="Loading..." link="/" />
            </div>
          </div>
        </div>
      </section>
    </Layout>
  )
}
export const query = graphql`
  query workpageImages {
    header: file(relativePath: { eq: "casestudypage/header.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    workimage1: file(relativePath: { eq: "work/yohani.png" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    workimage2: file(relativePath: { eq: "work/work2.jpg" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    workimage3: file(relativePath: { eq: "work/work3.jpg" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    workimage4: file(relativePath: { eq: "work/work4.jpg" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    workimage5: file(relativePath: { eq: "work/work5.jpg" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    workimage6: file(relativePath: { eq: "work/work6.jpg" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    workimage7: file(relativePath: { eq: "work/work7.jpg" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }

    workimage8: file(relativePath: { eq: "work/work8.jpg" }) {
      childImageSharp {
        gatsbyImageData(width: 1920, quality: 100, placeholder: BLURRED)
      }
    }
  }
`

export default Work
