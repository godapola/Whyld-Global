/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/pages/**/*.{js,jsx,ts,tsx}",
    "./src/components/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        "light-gray": "#F3F3F3",
        "dark-gray": "#737373",
        "secondary-dark": "#111111",
      },
    },
  },
  plugins: [require("tailwind-scrollbar-hide")],
}
